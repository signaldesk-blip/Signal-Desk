# Personal AI Trading Co-Pilot

## What will be added
- A new Co-Pilot section with separate conversations saved to your account. Each conversation has its own URL, history, and new-conversation action.
- A market assistant that checks timestamped price, weekly/daily/4-hour candles, open interest, funding and recent liquidations before discussing current conditions. Missing data is clearly disclosed.
- **Challenge my trade:** enter asset, direction, entry, stop, target and reasoning; see the calculated reward-to-risk ratio and ask the assistant to challenge the evidence, invalidation and target. Mathematical reward-to-risk is not presented as a success probability.
- **AI setup ideas:** a separate section for educational, conditional setups with supporting evidence, contradictory evidence and risks. These will not appear in the existing chart analyst.
- Clean white styling, accessible chat controls, collapsed data-check details and clear educational/not-financial-advice labels.

## Technical details
- Use the existing account sign-in boundary and owner-scoped Cloud conversation records; do not add profile or role fields.
- Route-derived conversation IDs, AI SDK streaming, AI Elements chat primitives and server-side data tools.
- Verify conversation isolation and reload restoration with two conversations, trade mathematics, authorization, streaming errors and chart-analyst separation.