<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Rules

- To re-theme a subtree (e.g. a dark chart panel) override the compiled `--color-*` tokens on that subtree's element, not only the raw `--*` tokens: Tailwind resolves the `:root` token declarations before inheritance, so utilities keep the light values otherwise.
- Keep chart surface colours token-driven so a canvas library reading them through a DOM probe follows the panel's theme.
- Journal reads/writes trades from the browser client; per-user isolation relies on RLS (user_id = auth.uid()).
- Learning visuals live in a shared lesson-ID mapping, separate from lesson text; precise diagrams use semantic tokens and explicitly identify hypothetical examples to avoid confusing them with live market data.
- Co-Pilot threads use owner-scoped account storage and route-derived IDs; stored UIMessage history is authoritative so clients cannot forge assistant/tool evidence.
- Co-Pilot market tools carry observation/retrieval timestamps and source caveats; setup ideas stay in their own section to keep the chart analyst informational.
- Setup cards are emitted through a server-validated tool with app-calculated reward-to-risk; LTF uses available 4h data and HTF uses daily/weekly to avoid implying unavailable minute-level analysis.
