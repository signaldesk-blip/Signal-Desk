CREATE TABLE public.copilot_threads (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL DEFAULT auth.uid(),
 title text NOT NULL DEFAULT 'New conversation',
 messages jsonb NOT NULL DEFAULT '[]'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.copilot_threads TO authenticated;
GRANT ALL ON public.copilot_threads TO service_role;
ALTER TABLE public.copilot_threads ENABLE ROW LEVEL SECURITY;
CREATE POLICY copilot_threads_owner ON public.copilot_threads FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX copilot_threads_user_updated ON public.copilot_threads (user_id, updated_at DESC);
CREATE TABLE public.copilot_access_blocks (
 user_id uuid PRIMARY KEY,
 reason text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.copilot_access_blocks TO authenticated;
GRANT ALL ON public.copilot_access_blocks TO service_role;
ALTER TABLE public.copilot_access_blocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY copilot_blocks_read ON public.copilot_access_blocks FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY copilot_blocks_insert ON public.copilot_access_blocks FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY copilot_blocks_update ON public.copilot_access_blocks FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());