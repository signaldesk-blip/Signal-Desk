import cryptoImage from "@/assets/learn-crypto.jpg";
import marketsImage from "@/assets/learn-markets.jpg";
import riskImage from "@/assets/learn-risk.jpg";
import analysisImage from "@/assets/learn-analysis.jpg";
import { LESSON_IMAGES } from "@/lib/lesson-images";

export const LEVEL_IMAGES: Record<string, { src: string; alt: string }> = {
  "level-1": { src: cryptoImage, alt: "Bitcoin, linked blockchain blocks and a hardware wallet" },
  "level-2": { src: marketsImage, alt: "Candlesticks, price levels and trading volume" },
  "level-3": { src: riskImage, alt: "A protective shield, a planning notebook and risk balance" },
  "level-4": { src: analysisImage, alt: "Different chart timeframes, a central bank and volume profile" },
};

const CHARTS: Record<string, { title: string; caption: string; kind: string }> = {
  "candlestick-charts": { title: "What one candle tells you", caption: "The body joins the opening and closing prices. The thin wick reaches the highest and lowest prices.", kind: "candles" },
  "support-and-resistance": { title: "A floor and a ceiling", caption: "Price has bounced near support and stalled near resistance in this example. Either level can break.", kind: "levels" },
  "supply-and-demand": { title: "Buying and selling areas", caption: "Demand and supply are price ranges, not exact prices. A return to a zone does not guarantee a bounce.", kind: "zones" },
  "market-structure": { title: "An upward staircase", caption: "Higher highs and higher lows form an uptrend. This pattern describes the past, not a guaranteed future.", kind: "trend" },
  "trading-volume": { title: "How much changed hands?", caption: "A taller bar means more coins traded during that period. Volume alone does not tell you where price goes next.", kind: "volume" },
  "volume-profile": { title: "Volume at each price", caption: "The longest horizontal bar marks the price with the most trading in this example: the point of control.", kind: "profile" },
  "risk-to-reward": { title: "Comparing possible loss and gain", caption: "An illustrative 1:3 comparison: a £100 planned loss versus a £300 potential gain. Neither outcome is guaranteed.", kind: "risk" },
};

const FLOWS: Record<string, { title: string; steps: string[]; caption: string }> = {
  "what-is-bitcoin": { title: "Digital money, shared records", steps: ["You send Bitcoin", "The network checks it", "The shared record updates"], caption: "Bitcoin ownership is recorded on the network rather than in a single bank's notebook." },
  "what-is-blockchain": { title: "Blocks linked together", steps: ["Block 1 · transactions", "Block 2 · links to 1", "Block 3 · links to 2"], caption: "Each new block refers to the previous block. Many computers hold copies of the same chain." },
  "what-are-altcoins": { title: "One category, many different coins", steps: ["Bitcoin · BTC", "Ethereum · an altcoin", "Other coins · altcoins"], caption: "Altcoin means a cryptocurrency other than Bitcoin. Sharing a category does not mean sharing the same features or risks." },
  "what-is-an-exchange": { title: "From money to crypto", steps: ["Deposit money", "Buy on an exchange", "Keep there or withdraw"], caption: "An exchange matches buyers and sellers. Fees and the risk of leaving funds with the exchange still matter." },
  "what-is-a-wallet": { title: "The key, not a bag of coins", steps: ["Wallet holds keys", "Keys authorise spending", "Coins stay on blockchain"], caption: "Your recovery phrase restores access to your keys. Never share it; the wallet does not physically contain your coins." },
  "spot-vs-futures": { title: "Owning versus a contract", steps: ["Spot · own the coin", "Futures · price contract", "Leverage · extra exposure"], caption: "Futures do not mean owning the underlying coin. Leverage increases both potential gains and losses." },
  "market-capitalisation": { title: "Coin price is only half the picture", steps: ["£2 per coin", "× 1 million circulating", "= £2 million market cap"], caption: "Illustrative numbers only. Market cap uses circulating supply; it is not the amount of cash invested." },
  "liquidity": { title: "Same order, different impact", steps: ["Many buyers · deep market", "A sale finds buyers", "Fewer buyers · more slippage"], caption: "In a shallow market, a large sale can consume available buy orders and execute at lower prices." },
  "position-sizing": { title: "Risk is not the purchase amount", steps: ["£5,000 account", "1% planned risk = £50", "5% stop distance → £1,000"], caption: "Illustrative arithmetic, not a recommended trade. Fees, gaps and slippage can make the actual loss larger." },
  "stop-losses": { title: "When the original idea no longer holds", steps: ["An idea depends on support", "Support breaks", "Stop order may trigger"], caption: "A stop is an order, not a guaranteed execution price. Fast markets and gaps can produce a larger loss." },
  "leverage-and-liquidation": { title: "A small move has a bigger effect", steps: ["£100 margin · 10×", "£1,000 exposure", "1% move ≈ £10 gain/loss"], caption: "Simplified example before fees. Liquidation depends on maintenance margin and exchange rules; it can happen before all margin is lost." },
  "trading-psychology": { title: "Break the emotional loop", steps: ["A loss or fear of missing out", "Pause instead of reacting", "Review the written plan"], caption: "A pause gives you space to decide without chasing a move or trying to win back a loss immediately." },
  "trading-plan": { title: "Decide, record, review", steps: ["Write your rules", "Record what happened", "Review patterns"], caption: "A plan and journal make decisions easier to review. They do not remove market risk." },
  "open-interest-funding": { title: "Two different views of futures", steps: ["OI · open contracts", "Positive funding · longs pay", "Negative funding · shorts pay"], caption: "Every futures contract has a long and a short. Rising open interest alone does not reveal the direction of the next move." },
  "liquidation-heatmaps": { title: "Estimated risk versus actual events", steps: ["Heatmap · estimated clusters", "Price reaches a threshold", "Liquidation · forced close"], caption: "A heatmap estimates potential liquidations. SignalDesk's OKX lines show reported past liquidations, not future liquidation thresholds." },
  "macroeconomic-analysis": { title: "The bigger economic picture", steps: ["Inflation and jobs data", "Interest-rate expectations", "Investors reassess risk"], caption: "Markets react to surprises versus expectations, not just whether a reading is high or low. Crypto's response can vary." },
  "multi-timeframe-analysis": { title: "Zoom from the big picture to detail", steps: ["Weekly · overall direction", "Daily · closer look", "4-hour · short-term moves"], caption: "The same market can rise on a weekly chart while falling over a few hours. Both views can be correct." },
  "portfolio-risk-management": { title: "Different coins can share one risk", steps: ["Bitcoin holding", "Altcoin holdings", "Shared crypto-market risk"], caption: "Several coins can fall together. Holding more coins is not necessarily the same as diversifying across independent assets." },
};

function ChartDiagram({ kind, title }: { kind: string; title: string }) {
  return (
    <svg viewBox="0 0 640 280" role="img" aria-label={title} className="w-full text-foreground" fill="none">
      <g stroke="currentColor" className="text-border"><path d="M50 30V235H600M50 85H600M50 140H600M50 195H600" /></g>
      {kind === "candles" ? <>
        <g className="text-bull" stroke="currentColor" strokeWidth="4"><path d="M210 40V220" /><rect x="183" y="85" width="54" height="85" fill="currentColor" /></g>
        <g className="text-bear" stroke="currentColor" strokeWidth="4"><path d="M445 40V220" /><rect x="418" y="85" width="54" height="85" fill="currentColor" /></g>
        <g fill="currentColor" fontSize="16"><text x="80" y="45">High</text><text x="80" y="95">Close</text><text x="80" y="175">Open</text><text x="80" y="225">Low</text><text x="490" y="95">Open</text><text x="490" y="175">Close</text><text x="171" y="263">Price rose</text><text x="405" y="263">Price fell</text></g>
      </> : kind === "risk" ? <>
        <rect x="80" y="80" width="140" height="55" rx="4" fill="currentColor" className="text-bear" /><rect x="80" y="155" width="420" height="55" rx="4" fill="currentColor" className="text-bull" />
        <g fill="currentColor" fontSize="18"><text x="80" y="60">Planned risk · £100</text><text x="80" y="250">Potential reward · £300</text></g>
      </> : kind === "profile" ? <>
        {[65, 120, 220, 420, 280, 140].map((w, i) => <rect key={i} x="80" y={38 + i * 30} width={w} height="20" rx="2" fill="currentColor" className={i === 3 ? "text-primary" : "text-primary/30"} />)}
        <text x="80" y="263" fill="currentColor" fontSize="17">Longest bar = most volume at that price</text>
      </> : kind === "volume" ? <>
        {[35, 60, 48, 75, 55, 170, 95, 65].map((h, i) => <rect key={i} x={80 + i * 62} y={235 - h} width="34" height={h} fill="currentColor" className={i === 5 ? "text-primary" : "text-bull/60"} />)}
        <text x="375" y="48" fill="currentColor" fontSize="17">More activity</text><text x="80" y="263" fill="currentColor" fontSize="16">Earlier → later</text>
      </> : <>
        {kind !== "trend" && <>
          {kind === "zones" && <><rect x="50" y="48" width="550" height="42" fill="currentColor" className="text-bear/10" /><rect x="50" y="180" width="550" height="42" fill="currentColor" className="text-bull/10" /></>}
          <path d="M50 70H600" stroke="currentColor" className="text-bear" strokeWidth="2" strokeDasharray="6 5" /><path d="M50 200H600" stroke="currentColor" className="text-bull" strokeWidth="2" strokeDasharray="6 5" />
          <text x="60" y="44" fill="currentColor" className="text-bear" fontSize="17">{kind === "zones" ? "Supply · selling area" : "Resistance · ceiling"}</text><text x="60" y="260" fill="currentColor" className="text-bull" fontSize="17">{kind === "zones" ? "Demand · buying area" : "Support · floor"}</text>
        </>}
        <path d={kind === "trend" ? "M65 220L145 165L200 195L285 110L345 150L435 60L490 105L575 35" : "M65 140L125 200L185 125L245 70L310 135L365 200L430 135L495 70L565 145"} stroke="currentColor" className="text-primary" strokeWidth="4" strokeLinejoin="round" />
        {kind === "trend" && <g fill="currentColor" fontSize="16"><text x="260" y="90">Higher high</text><text x="320" y="183">Higher low</text><text x="410" y="40">Higher high</text><text x="470" y="135">Higher low</text></g>}
      </>}
    </svg>
  );
}

export function LessonVisual({ lessonId }: { lessonId: string }) {
  const chart = CHARTS[lessonId];
  const flow = FLOWS[lessonId];
  if (!chart && !flow) return null;
  return (
    <figure className="mt-6 border-y border-border bg-card py-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h2 className="font-display text-lg font-semibold">{chart?.title ?? flow?.title}</h2>
        <span className="text-xs text-muted-foreground">Illustrative example · not live data</span>
      </div>
      {LESSON_IMAGES[lessonId] && <img src={LESSON_IMAGES[lessonId]} alt={`Illustration: ${chart?.title ?? flow?.title}`} width={640} height={720} className="mx-auto mb-6 max-h-80 w-full object-contain" />}
      {chart ? <ChartDiagram kind={chart.kind} title={chart.title} /> : <div className="grid gap-3 sm:grid-cols-3">
        {flow?.steps.map((step, i) => <div key={step} className="relative flex min-h-32 flex-col justify-center border-l-2 border-primary bg-accent/40 p-4">
          <span className="mb-3 font-display text-3xl font-bold text-primary/40">0{i + 1}</span>
          <p className="text-base font-medium">{step}</p>
        </div>)}
      </div>}
      <figcaption className="mt-4 text-sm leading-relaxed text-muted-foreground">{chart?.caption ?? flow?.caption}</figcaption>
    </figure>
  );
}