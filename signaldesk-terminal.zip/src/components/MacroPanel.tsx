import { ArrowDownRight, ArrowUpRight, Landmark, Minus } from "lucide-react";

type MacroStat = { key: string; label: string; value: number; previous: number | null; unit: string; date: string; note: string };

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const asOf = (d: string) => { const [y, m, day] = d.split("-"); return `${day} ${MONTHS[Number(m) - 1] ?? ""} ${y}`; };

export function MacroPanel({ stats = [] }: { stats?: MacroStat[] | undefined }) {
  return (
    <section className="rounded-xl border border-border bg-card">
      <h2 className="flex items-center gap-2 border-b border-border px-4 py-3 text-sm font-semibold">
        <Landmark className="size-4 text-primary" />US economy — latest real figures
        <span className="text-xs font-normal text-muted-foreground">· source: Federal Reserve (FRED)</span>
      </h2>
      {stats.length ? (
        <div className="grid gap-px overflow-hidden rounded-b-xl bg-border sm:grid-cols-2 lg:grid-cols-3">
          {stats.map((s) => {
            const diff = s.previous == null ? 0 : s.value - s.previous;
            const Icon = Math.abs(diff) < 0.005 ? Minus : diff > 0 ? ArrowUpRight : ArrowDownRight;
            return (
              <div key={s.key} className="bg-card px-4 py-3">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="font-display text-2xl font-bold">{s.value.toFixed(2)}{s.unit}</span>
                  {s.previous != null && (
                    <span className="inline-flex items-center gap-0.5 text-xs text-muted-foreground"><Icon className="size-3" />from {s.previous.toFixed(2)}{s.unit}</span>
                  )}
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground">{s.note} · as of {asOf(s.date)}</p>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="px-4 py-6 text-sm text-muted-foreground">Economic figures are unavailable right now — check back shortly.</p>
      )}
    </section>
  );
}
