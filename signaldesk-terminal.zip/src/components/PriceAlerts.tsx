import { useEffect, useRef, useState } from "react";
import { Bell, BellRing, Trash2 } from "lucide-react";
import { toast } from "sonner";

type Mover = { symbol: string; price: number };
type Alert = { id: string; symbol: string; price: number; kind: "support" | "resistance"; dir: "above" | "below"; hit?: number };

const KEY = "signaldesk-price-alerts";
const fmt = (n: number) => (n >= 1000 ? n.toLocaleString("en-US", { maximumFractionDigits: 0 }) : n >= 1 ? n.toFixed(2) : n.toPrecision(4));

function beep() {
  try {
    const ctx = new AudioContext();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination); o.frequency.value = 880; g.gain.value = 0.08;
    o.start(); o.stop(ctx.currentTime + 0.35);
  } catch { /* sound unavailable */ }
}

async function priceOf(symbol: string): Promise<number | null> {
  try {
    const r = await fetch(`https://data-api.binance.vision/api/v3/ticker/price?symbol=${symbol}USDT`);
    if (r.ok) {
      const p = Number(((await r.json()) as { price: string }).price);
      if (Number.isFinite(p) && p > 0) return p;
    }
  } catch { /* try backup */ }
  try {
    const r = await fetch(`https://www.okx.com/api/v5/market/ticker?instId=${symbol}-USDT`);
    if (!r.ok) return null;
    const p = Number(((await r.json()) as { data?: { last: string }[] }).data?.[0]?.last);
    return Number.isFinite(p) && p > 0 ? p : null;
  } catch { return null; }
}

export function PriceAlerts({ majors }: { majors: Mover[] }) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [symbol, setSymbol] = useState("BTC");
  const [price, setPrice] = useState("");
  const [kind, setKind] = useState<Alert["kind"]>("support");
  const [perm, setPerm] = useState<string>("default");
  const [live, setLive] = useState<Record<string, number>>({});
  const ready = useRef(false);

  useEffect(() => {
    try { setAlerts(JSON.parse(localStorage.getItem(KEY) ?? "[]") as Alert[]); } catch { /* ignore */ }
    if ("Notification" in window) setPerm(Notification.permission);
    ready.current = true;
  }, []);
  useEffect(() => { if (ready.current) localStorage.setItem(KEY, JSON.stringify(alerts)); }, [alerts]);

  // Check active alerts every 20s while the site is open.
  useEffect(() => {
    const active = alerts.filter((a) => !a.hit);
    if (!active.length) return;
    const check = async () => {
      const syms = [...new Set(active.map((a) => a.symbol))];
      const prices = Object.fromEntries(await Promise.all(syms.map(async (s) => [s, await priceOf(s)] as const)));
      setLive((l) => ({ ...l, ...Object.fromEntries(Object.entries(prices).filter(([, v]) => v != null)) as Record<string, number> }));
      const fired: string[] = [];
      for (const a of active) {
        const p = prices[a.symbol];
        if (p == null) continue;
        if ((a.dir === "below" && p <= a.price) || (a.dir === "above" && p >= a.price)) {
          fired.push(a.id);
          const msg = `${a.symbol} reached your ${a.kind} at $${fmt(a.price)} (now $${fmt(p)})`;
          toast(msg); beep();
          if ("Notification" in window && Notification.permission === "granted") new Notification("SignalDesk price alert", { body: msg });
        }
      }
      if (fired.length) setAlerts((as) => as.map((a) => (fired.includes(a.id) ? { ...a, hit: Date.now() } : a)));
    };
    void check();
    const t = setInterval(check, 20_000);
    return () => clearInterval(t);
  }, [alerts]);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const level = Number(price);
    const sym = symbol.trim().toUpperCase();
    if (!sym || !(level > 0)) { toast("Enter a coin and a price."); return; }
    const now = majors.find((m) => m.symbol === sym)?.price ?? (await priceOf(sym));
    if (now == null) { toast(`No live price found for ${sym}.`); return; }
    if ("Notification" in window && Notification.permission === "default") setPerm(await Notification.requestPermission());
    setAlerts((as) => [...as, { id: crypto.randomUUID(), symbol: sym, price: level, kind, dir: level < now ? "below" : "above" }]);
    setLive((l) => ({ ...l, [sym]: now }));
    setPrice("");
    toast(`Alert set: ${sym} ${level < now ? "falls to" : "rises to"} $${fmt(level)}`);
  };

  return (
    <section className="rounded-xl border border-border bg-card">
      <h2 className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3 text-sm font-semibold">
        <Bell className="size-4 text-primary" />Price alerts
        <span className="text-xs font-normal text-muted-foreground">· get a pop-up when a coin hits your support or resistance level (while this site is open)</span>
      </h2>
      <form onSubmit={add} className="flex flex-wrap items-end gap-2 border-b border-border px-4 py-3 text-sm">
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">Coin
          <input list="alert-coins" value={symbol} onChange={(e) => setSymbol(e.target.value)} className="w-24 rounded-md border border-border bg-background px-2 py-1.5 text-sm text-foreground" />
          <datalist id="alert-coins">{majors.map((m) => <option key={m.symbol} value={m.symbol} />)}</datalist>
        </label>
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">Level type
          <select value={kind} onChange={(e) => setKind(e.target.value as Alert["kind"])} className="rounded-md border border-border bg-background px-2 py-1.5 text-sm text-foreground">
            <option value="support">Support (floor)</option><option value="resistance">Resistance (ceiling)</option>
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">Price ($)
          <input inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder={fmt(majors.find((m) => m.symbol === symbol.toUpperCase())?.price ?? 0)} className="w-32 rounded-md border border-border bg-background px-2 py-1.5 text-sm text-foreground" />
        </label>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Add alert</button>
        {perm === "denied" && <span className="text-xs text-bear">Browser notifications are blocked — you'll still see an on-page pop-up and hear a beep.</span>}
      </form>
      {alerts.length ? (
        <ul className="divide-y divide-border/60 text-sm">
          {alerts.map((a) => (
            <li key={a.id} className={`flex items-center gap-3 px-4 py-2 ${a.hit ? "bg-accent" : ""}`}>
              {a.hit ? <BellRing className="size-4 text-liq" /> : <Bell className="size-4 text-muted-foreground" />}
              <span className="font-semibold">{a.symbol}</span>
              <span className={a.kind === "support" ? "text-bull" : "text-bear"}>{a.kind}</span>
              <span className="font-mono">${fmt(a.price)}</span>
              <span className="text-xs text-muted-foreground">{a.hit ? "Triggered" : `when price ${a.dir === "below" ? "falls to" : "rises to"} it${live[a.symbol] ? ` · now $${fmt(live[a.symbol]!)}` : ""}`}</span>
              <button aria-label="Delete alert" onClick={() => setAlerts((as) => as.filter((x) => x.id !== a.id))} className="ml-auto text-muted-foreground hover:text-bear"><Trash2 className="size-4" /></button>
            </li>
          ))}
        </ul>
      ) : <p className="px-4 py-4 text-sm text-muted-foreground">No alerts yet. Tip: use the support and resistance levels from the AI Chart Analyst.</p>}
    </section>
  );
}
