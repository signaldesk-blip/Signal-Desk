import { useEffect, useRef, useState } from "react";
import {
  CandlestickSeries,
  ColorType,
  createChart,
  HistogramSeries,
  LineSeries,
  LineStyle,
  type IChartApi,
  type ISeriesApi,
  type UTCTimestamp,
} from "lightweight-charts";

export type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
export type Zone = { type: "demand" | "supply"; low: number; high: number; timeframe: string; label: string };
export type Level = { price: number; type: "support" | "resistance"; label: string };
export type Liq = { price: number; side: "longs" | "shorts"; usd?: number };
export type Layers = { zones: boolean; levels: boolean; liquidations: boolean; oi?: boolean };
export type OIPoint = { time: number; usd: number };

// Resolve any CSS color (incl. oklch tokens) to rgba for the canvas library.
// Pass the chart element as `root` so a .chart-dark panel's overrides are picked up.
function cssColor(varName: string, alpha = 1, root: HTMLElement = document.body): string {
  const probe = document.createElement("span");
  probe.style.color = `color-mix(in srgb, var(${varName}) 100%, transparent)`;
  root.appendChild(probe);
  const out = getComputedStyle(probe).color;
  probe.remove();
  const nums = out.match(/[\d.]+/g)?.map(Number) ?? [128, 128, 128];
  const isSrgbFn = out.startsWith("color(");
  const [r, g, b] = isSrgbFn ? nums.slice(0, 3).map((v) => Math.round(v * 255)) : nums.slice(0, 3);
  return `rgba(${r},${g},${b},${alpha})`;
}

function rsiSeries(closes: number[], period = 14) {
  const out: (number | null)[] = closes.map(() => null);
  if (closes.length <= period) return out;
  let g = 0, l = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i]! - closes[i - 1]!;
    if (d >= 0) g += d; else l -= d;
  }
  g /= period; l /= period;
  out[period] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i]! - closes[i - 1]!;
    g = (g * (period - 1) + Math.max(d, 0)) / period;
    l = (l * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  }
  return out;
}

export function MarketChart({
  candles, zones, levels, liquidations, layers, openInterest,
}: {
  candles: Candle[]; zones: Zone[]; levels: Level[]; liquidations: Liq[]; layers: Layers; openInterest?: OIPoint[] | undefined;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const [boxes, setBoxes] = useState<{ top: number; height: number; z: Zone }[]>([]);

  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const fg = cssColor("--muted-foreground", 1, el);
    const grid = cssColor("--border", 0.5, el);
    const bull = cssColor("--bull", 1, el);
    const bear = cssColor("--bear", 1, el);
    const primary = cssColor("--primary", 1, el);

    const chart = createChart(el, {
      autoSize: true,
      localization: { locale: "en-US" },
      layout: { background: { type: ColorType.Solid, color: "transparent" }, textColor: fg, fontFamily: "JetBrains Mono", panes: { separatorColor: grid } },
      grid: { vertLines: { color: grid }, horzLines: { color: grid } },
      rightPriceScale: { borderColor: grid },
      timeScale: { borderColor: grid, timeVisible: true },
      crosshair: { mode: 0 },
    });
    chartRef.current = chart;

    const series = chart.addSeries(CandlestickSeries, {
      upColor: bull, downColor: bear, borderVisible: false, wickUpColor: bull, wickDownColor: bear,
    });
    series.setData(candles.map((c) => ({ ...c, time: c.time as UTCTimestamp })));
    seriesRef.current = series;

    const vol = chart.addSeries(HistogramSeries, { priceFormat: { type: "volume" }, priceLineVisible: false, lastValueVisible: false }, 1);
    vol.setData(candles.map((c) => ({ time: c.time as UTCTimestamp, value: c.volume, color: c.close >= c.open ? cssColor("--bull", 0.5, el) : cssColor("--bear", 0.5, el) })));

    const rsiLine = chart.addSeries(LineSeries, { color: primary, lineWidth: 1, priceLineVisible: false }, 2);
    const r = rsiSeries(candles.map((c) => c.close));
    rsiLine.setData(candles.flatMap((c, i) => (r[i] == null ? [] : [{ time: c.time as UTCTimestamp, value: r[i]! }])));
    rsiLine.createPriceLine({ price: 70, color: bear, lineStyle: LineStyle.Dotted, lineWidth: 1, axisLabelVisible: false, title: "" });
    rsiLine.createPriceLine({ price: 30, color: bull, lineStyle: LineStyle.Dotted, lineWidth: 1, axisLabelVisible: false, title: "" });

    // Real open interest, snapped to candle times so it lines up with price.
    const oiPts = layers.oi === false ? [] : openInterest ?? [];
    if (oiPts.length) {
      const oiLine = chart.addSeries(LineSeries, { color: cssColor("--liq", 1, el), lineWidth: 1, priceLineVisible: false, title: "OI", priceFormat: { type: "custom", formatter: (v: number) => `$${v >= 1e9 ? (v / 1e9).toFixed(2) + "B" : (v / 1e6).toFixed(0) + "M"}` } }, 3);
      const out: { time: UTCTimestamp; value: number }[] = [];
      let j = 0;
      for (let i = 0; i < candles.length; i++) {
        const end = candles[i + 1]?.time ?? Infinity;
        while (j < oiPts.length - 1 && oiPts[j + 1]!.time < end) j++;
        const p = oiPts[j]!;
        if (p.time < end && p.time >= candles[i]!.time - 86400 * 7) out.push({ time: candles[i]!.time as UTCTimestamp, value: p.usd });
      }
      oiLine.setData(out);
    }

    const panes = chart.panes();
    panes[0]?.setHeight(340);
    panes[1]?.setHeight(70);
    panes[2]?.setHeight(80);
    panes[3]?.setHeight(80);

    if (layers.levels) {
      for (const l of levels) {
        series.createPriceLine({ price: l.price, color: l.type === "support" ? bull : bear, lineStyle: LineStyle.Dashed, lineWidth: 1, axisLabelVisible: true, title: l.label });
      }
    }
    if (layers.liquidations) {
      const liq = cssColor("--liq", 0.85, el);
      for (const q of liquidations ?? []) {
        const amt = q.usd ? ` $${q.usd >= 1e6 ? (q.usd / 1e6).toFixed(1) + "M" : Math.round(q.usd / 1e3) + "K"}` : "";
        series.createPriceLine({ price: q.price, color: liq, lineStyle: LineStyle.SparseDotted, lineWidth: 1, axisLabelVisible: false, title: `${q.side === "longs" ? "Longs" : "Shorts"} liq${amt}` });
      }
    }
    const n = candles.length;
    chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, n - 90), to: n + 5 });

    // Zone rectangles drawn as overlays, kept in sync with price scale.
    let raf = 0;
    let last = "";
    const tick = () => {
      const s = seriesRef.current;
      if (s && layers.zones) {
        const next = zones.flatMap((z) => {
          const a = s.priceToCoordinate(z.high);
          const b = s.priceToCoordinate(z.low);
          if (a == null || b == null) return [];
          const top = Math.max(0, Math.min(a, b));
          const bottom = Math.min(340, Math.max(a, b));
          if (bottom <= 0 || top >= 340) return [];
          return [{ top, height: Math.max(3, bottom - top), z }];
        });
        const key = next.map((n) => `${n.top.toFixed(1)}:${n.height.toFixed(1)}`).join("|");
        if (key !== last) { last = key; setBoxes(next); }
      } else if (last !== "none") { last = "none"; setBoxes([]); }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
    };
  }, [candles, zones, levels, liquidations, layers, openInterest]);

  return (
    <div className={`relative w-full ${openInterest?.length && layers.oi !== false ? "h-[590px]" : "h-[500px]"}`}>
      <div ref={wrap} className="absolute inset-0" />
      <div className="pointer-events-none absolute inset-y-0 left-0 right-[70px] overflow-hidden">
        {boxes.map(({ top, height, z }, i) => (
          <div
            key={i}
            className={`absolute left-0 right-0 border-y ${z.type === "demand" ? "border-bull/60 bg-bull/15" : "border-bear/60 bg-bear/15"}`}
            style={{ top, height }}
          >
            {height > 12 && <span className={`absolute left-2 top-0.5 text-[10px] font-semibold uppercase tracking-wider ${z.type === "demand" ? "text-bull" : "text-bear"}`}>
              {z.type} · {z.label} · {z.timeframe}
            </span>}
          </div>
        ))}
      </div>
    </div>
  );
}
