import { queryOptions, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import {
  createCopilotThread,
  deleteCopilotThread,
  listCopilotThreads,
} from "@/lib/copilot.functions";

export const copilotThreadsQuery = queryOptions({
  queryKey: ["copilot-threads"],
  queryFn: () => listCopilotThreads(),
});

export function useCopilotThreads() {
  const { data: threads } = useSuspenseQuery(copilotThreadsQuery);
  const create = useServerFn(createCopilotThread);
  const remove = useServerFn(deleteCopilotThread);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [working, setWorking] = useState(false);
  const [error, setError] = useState("");
  async function newThread(title = "New conversation", draft?: string) {
    if (working) return;
    setWorking(true);
    setError("");
    try {
      const result = await create({ data: { title } });
      await queryClient.invalidateQueries({ queryKey: ["copilot-threads"] });
      await navigate({
        to: "/copilot/$threadId",
        params: { threadId: result.id },
        search: { draft },
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create a conversation.");
    } finally {
      setWorking(false);
    }
  }
  async function deleteThread(id: string) {
    if (!window.confirm("Delete this conversation? This cannot be undone.")) return;
    setWorking(true);
    try {
      await remove({ data: { threadId: id } });
      await queryClient.invalidateQueries({ queryKey: ["copilot-threads"] });
      await navigate({ to: "/copilot" });
    } catch {
      setError("Could not delete this conversation.");
    } finally {
      setWorking(false);
    }
  }
  return { threads, working, error, newThread, deleteThread };
}
