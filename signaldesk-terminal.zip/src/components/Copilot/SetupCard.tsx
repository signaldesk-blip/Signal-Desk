import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import type { SetupIdea } from "@/lib/setup-ideas";

const price = (n: number) =>
  `$${n.toLocaleString("en-US", { maximumFractionDigits: n < 1 ? 6 : 2 })}`;
export function SetupCard({ idea }: { idea: SetupIdea }) {
  return (
    <article className="my-3 overflow-hidden rounded-lg border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <strong className="text-base">{idea.asset}</strong>
          <span
            className={`flex items-center gap-1 text-sm font-semibold ${idea.direction === "long" ? "text-bull" : "text-bear"}`}
          >
            {idea.direction === "long" ? (
              <ArrowUpRight className="size-4" />
            ) : (
              <ArrowDownRight className="size-4" />
            )}
            {idea.direction === "long" ? "Long" : "Short"}
          </span>
        </div>
        <span className="text-xs text-muted-foreground">{idea.timeframe} · Conditional</span>
      </div>
      <dl className="grid grid-cols-2 gap-y-4 px-4 py-5 sm:grid-cols-4">
        {[
          ["Entry", price(idea.entry)],
          ["Stop-loss", price(idea.stop)],
          ["Target", price(idea.target)],
          ["Reward / risk", `${idea.rewardToRisk.toFixed(2)} : 1`],
        ].map(([label, value]) => (
          <div key={label}>
            <dt className="text-xs text-muted-foreground">{label}</dt>
            <dd className="mt-1 text-lg font-semibold tabular-nums">{value}</dd>
          </div>
        ))}
      </dl>
      <div className="space-y-3 border-t border-border px-4 py-4 text-sm leading-relaxed">
        <div>
          <p className="font-semibold">Why this idea?</p>
          <p className="mt-1 text-muted-foreground">{idea.explanation}</p>
        </div>
        <p>
          <span className="font-semibold">Wait for: </span>
          {idea.confirmation}
        </p>
        <p>
          <span className="font-semibold">What could go wrong: </span>
          {idea.opposingEvidence}
        </p>
        <p>
          <span className="font-semibold">Invalid if: </span>
          {idea.invalidation}
        </p>
        <p className="text-xs text-muted-foreground">
          Data checked {idea.checkedAt} · Expires {idea.expiresAt}
        </p>
        <p className="text-xs text-muted-foreground">
          Hypothetical prices · excludes fees and slippage · ratio is not a success probability
        </p>
      </div>
    </article>
  );
}
