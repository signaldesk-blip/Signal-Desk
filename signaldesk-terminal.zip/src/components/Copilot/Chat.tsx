import { useEffect, useMemo, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, isToolUIPart, type UIMessage } from "ai";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
} from "@/components/ai-elements/prompt-input";
import {
  Tool,
  ToolHeader,
  ToolContent,
  ToolInput,
  ToolOutput,
} from "@/components/ai-elements/tool";
import { Reasoning, ReasoningTrigger, ReasoningContent } from "@/components/ai-elements/reasoning";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Button } from "@/components/ui/button";
import { CopilotIdentity } from "./Shell";
import { restoreCopilotAccess } from "@/lib/copilot.functions";
import { SetupCard } from "./SetupCard";
import type { SetupIdea } from "@/lib/setup-ideas";

export function CopilotChat({
  threadId,
  initialMessages,
  draft = "",
}: {
  threadId: string;
  initialMessages: UIMessage[];
  draft?: string;
}) {
  const [input, setInput] = useState(draft);
  const [notice, setNotice] = useState("");
  const textarea = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();
  const restore = useServerFn(restoreCopilotAccess);
  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/copilot",
        body: { threadId },
        headers: async () => {
          const { data } = await supabase.auth.getSession();
          return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {};
        },
        fetch: async (url, init) => {
          const response = await fetch(url, init);
          if (!response.ok) {
            const body = (await response.json().catch(() => null)) as { error?: string } | null;
            throw new Error(body?.error ?? "Could not reach your Co-Pilot. Please try again.");
          }
          return response;
        },
      }),
    [threadId],
  );
  const { messages, sendMessage, status, stop, error } = useChat({
    id: threadId,
    messages: initialMessages,
    transport,
    onError: (error) => {
      setNotice(error.message);
    },
    onFinish: () => {
      void queryClient.invalidateQueries({ queryKey: ["copilot-threads"] });
    },
  });
  const busy = status === "submitted" || status === "streaming";
  useEffect(() => {
    const active = document.activeElement;
    if (
      !active ||
      active === document.body ||
      active === textarea.current ||
      (!(active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) &&
        !active.closest('[role="dialog"]'))
    )
      textarea.current?.focus();
  }, [threadId, status]);
  async function send(text: string) {
    if (busy || !text.trim()) return;
    setNotice("");
    setInput("");
    await sendMessage({ text: text.trim() });
    textarea.current?.focus();
  }
  return (
    <div className="flex h-[calc(100dvh-74px)] min-h-[600px] flex-col">
      <div className="flex items-center gap-3 border-b border-border px-5 py-4">
        <CopilotIdentity small />
        <div>
          <h1 className="font-semibold">Market Co-Pilot</h1>
          <p className="text-xs text-muted-foreground">
            Timestamped evidence · independent perspective
          </p>
        </div>
      </div>
      <Conversation className="min-h-0 flex-1">
        <ConversationContent className="mx-auto w-full max-w-3xl gap-5 px-5 py-6">
          {!messages.length && (
            <div className="py-12">
              <CopilotIdentity />
              <h2 className="mt-5 font-display text-2xl font-semibold">A second pair of eyes.</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                What would you like to understand about the market?
              </p>
              <div className="mt-6 grid gap-2 sm:grid-cols-2">
                {[
                  "Analyse SOL on weekly, daily and 4-hour charts.",
                  "What are the strongest arguments for and against Bitcoin here?",
                  "Compare SOL, INJ and SUI market structure.",
                  "Explain Bitcoin's chart as if I'm new to trading.",
                ].map((text) => (
                  <Button
                    key={text}
                    variant="outline"
                    className="h-auto justify-start whitespace-normal py-3 text-left"
                    onClick={() => {
                      setInput(text);
                      textarea.current?.focus();
                    }}
                  >
                    {text}
                  </Button>
                ))}
              </div>
            </div>
          )}
          {messages.map((message) => (
            <Message key={message.id} from={message.role} className="max-w-full">
              {message.role === "assistant" && (
                <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                  <CopilotIdentity small />
                  SignalDesk Co-Pilot
                </div>
              )}
              <MessageContent
                className={
                  message.role === "user"
                    ? "group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground"
                    : "w-full bg-transparent"
                }
              >
                {message.parts.map((part, i) => {
                  if (part.type === "text")
                    return message.role === "assistant" ? (
                      <MessageResponse key={i}>{part.text}</MessageResponse>
                    ) : (
                      <p className="whitespace-pre-wrap" key={i}>
                        {part.text}
                      </p>
                    );
                  if (part.type === "reasoning")
                    return (
                      <Reasoning
                        key={i}
                        defaultOpen={false}
                        isStreaming={part.state === "streaming"}
                      >
                        <ReasoningTrigger />
                        <ReasoningContent>{part.text}</ReasoningContent>
                      </Reasoning>
                    );
                  if (
                    isToolUIPart(part) &&
                    part.type === "tool-presentSetup" &&
                    part.state === "output-available"
                  ) {
                    const idea = part.output as SetupIdea;
                    return (
                      <div key={part.toolCallId} className="w-full">
                        <SetupCard idea={idea} />
                        <Tool defaultOpen={false}>
                          <ToolHeader
                            type={part.type}
                            state={part.state}
                            title="Setup calculation"
                          />
                          <ToolContent>
                            <ToolInput input={part.input} />
                            <ToolOutput output={part.output} errorText={part.errorText} />
                          </ToolContent>
                        </Tool>
                      </div>
                    );
                  }
                  if (isToolUIPart(part))
                    return (
                      <Tool key={part.toolCallId} defaultOpen={false}>
                        {part.type === "dynamic-tool" ? (
                          <ToolHeader
                            type={part.type}
                            toolName={part.toolName}
                            state={part.state}
                          />
                        ) : (
                          <ToolHeader
                            type={part.type}
                            state={part.state}
                            title={
                              part.type === "tool-marketData"
                                ? "Market data check"
                                : part.type === "tool-macroData"
                                  ? "Macro data check"
                                  : "Setup candidate scan"
                            }
                          />
                        )}
                        <ToolContent>
                          <ToolInput input={part.input} />
                          <ToolOutput output={part.output} errorText={part.errorText} />
                        </ToolContent>
                      </Tool>
                    );
                  return null;
                })}
              </MessageContent>
            </Message>
          ))}
          {status === "submitted" && <Shimmer>Checking the evidence…</Shimmer>}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>
      <div className="mx-auto w-full max-w-3xl px-5 pb-5 pt-3">
        {(notice || error) && (
          <div
            role="alert"
            className="mb-3 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive"
          >
            <p>{notice || error?.message}</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-2"
              onClick={async () => {
                try {
                  await restore();
                  setNotice(
                    "Access reset. Send a fresh message only after the site owner has restored AI access.",
                  );
                } catch {
                  setNotice("Could not reset access.");
                }
              }}
            >
              Access restored — enable a fresh request
            </Button>
          </div>
        )}
        <PromptInput onSubmit={({ text }) => send(text)}>
          <PromptInputTextarea
            ref={textarea}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            autoFocus
            placeholder="Ask about a coin, a chart or your reasoning…"
            aria-label="Message your Co-Pilot"
            className="min-h-24 text-base"
            maxLength={12000}
          />
          <PromptInputFooter className="justify-between">
            <span className="text-xs text-muted-foreground">
              Educational only · not financial advice
            </span>
            <PromptInputSubmit
              status={status}
              onStop={stop}
              disabled={!busy && !input.trim()}
              className="shrink-0"
            />
          </PromptInputFooter>
        </PromptInput>
      </div>
    </div>
  );
}
