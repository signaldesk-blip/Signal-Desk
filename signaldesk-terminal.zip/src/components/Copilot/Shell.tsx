import { Link } from "@tanstack/react-router";
import { Activity, Compass, Plus, Trash2 } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";

type Thread = { id: string; title: string; updated_at: string };

export function CopilotIdentity({ small = false }: { small?: boolean }) {
  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground ${small ? "size-8" : "size-12"}`}
    >
      <Compass className={small ? "size-5" : "size-7"} />
    </div>
  );
}

export function CopilotShell({
  children,
  threads,
  activeId,
  onNew,
  onDelete,
  working,
}: {
  children: ReactNode;
  threads: Thread[];
  activeId?: string;
  onNew: () => void;
  onDelete: (id: string) => void;
  working?: boolean;
}) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
            <Activity className="size-5 text-primary" />
            SignalDesk
          </Link>
          <nav className="flex flex-wrap items-center gap-1 text-sm">
            <Button asChild variant="ghost" size="sm">
              <Link to="/">Dashboard</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/analyze" search={{ coin: undefined }}>
                Charts
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/scanner">Scanner</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/learn" search={{ lesson: undefined }}>
                Learn
              </Link>
            </Button>
            <Button asChild variant="secondary" size="sm">
              <Link to="/copilot">Co-Pilot</Link>
            </Button>
          </nav>
        </div>
      </header>
      <div className="mx-auto grid max-w-7xl md:grid-cols-[220px_minmax(0,1fr)]">
        <aside className="border-b border-border p-4 md:min-h-[calc(100dvh-74px)] md:border-r md:border-b-0">
          <div className="mb-4 flex items-center gap-2">
            <CopilotIdentity small />
            <p className="text-sm font-semibold">Your Co-Pilot</p>
          </div>
          <Button className="mb-4 w-full" onClick={onNew} disabled={working}>
            <Plus className="size-4" />
            New conversation
          </Button>
          <div className="mb-4 flex gap-1 md:flex-col">
            <Button asChild variant="ghost" className="justify-start">
              <Link to="/challenge">Challenge my trade</Link>
            </Button>
            <Button asChild variant="ghost" className="justify-start">
              <Link to="/setups">AI setup ideas</Link>
            </Button>
          </div>
          <p className="mb-2 text-xs font-semibold text-muted-foreground">Saved conversations</p>
          <div className="max-h-40 space-y-1 overflow-y-auto md:max-h-[55dvh]">
            {threads.map((thread) => (
              <div
                key={thread.id}
                className={`flex items-center rounded-md ${activeId === thread.id ? "bg-accent" : "hover:bg-accent/60"}`}
              >
                <Link
                  to="/copilot/$threadId"
                  params={{ threadId: thread.id }}
                  search={{ draft: undefined }}
                  className="min-w-0 flex-1 truncate px-2 py-2 text-sm"
                  title={thread.title}
                >
                  {thread.title}
                </Link>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label={`Delete ${thread.title}`}
                  disabled={working}
                  onClick={() => onDelete(thread.id)}
                >
                  <Trash2 className="size-3.5 text-muted-foreground" />
                </Button>
              </div>
            ))}
            {!threads.length && (
              <p className="py-2 text-xs text-muted-foreground">No conversations yet.</p>
            )}
          </div>
          <p className="mt-5 text-xs leading-relaxed text-muted-foreground">
            Educational only. Not financial advice. Crypto can lose value.
          </p>
        </aside>
        <main className="min-w-0">{children}</main>
      </div>
    </div>
  );
}
