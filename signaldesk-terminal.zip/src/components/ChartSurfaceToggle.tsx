import { Moon, Sun } from "lucide-react";

/** Small segmented control: flip the chart surface between a white and a black canvas. */
export function ChartSurfaceToggle({ dark, onChoose }: { dark: boolean; onChoose: (dark: boolean) => void }) {
  const base = "flex items-center gap-1 rounded px-2 py-1 text-[11px] font-semibold transition-colors";
  const idle = "text-muted-foreground hover:text-foreground";
  const active = "bg-accent text-accent-foreground";
  return (
    <div className="flex items-center gap-0.5 rounded border border-border p-0.5" role="group" aria-label="Chart background">
      <button type="button" aria-pressed={!dark} title="White chart background" onClick={() => onChoose(false)}
        className={`${base} ${dark ? idle : active}`}>
        <Sun className="size-3" />White
      </button>
      <button type="button" aria-pressed={dark} title="Black chart background" onClick={() => onChoose(true)}
        className={`${base} ${dark ? active : idle}`}>
        <Moon className="size-3" />Black
      </button>
    </div>
  );
}
