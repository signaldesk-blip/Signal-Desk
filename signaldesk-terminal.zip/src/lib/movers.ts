// Browser-safe coin price helpers, shared by the server dashboard and the in-browser fallback.
export type Mover = { symbol: string; price: number; change: number; volume: number };
export type GlobalStats = { marketCap: number; volume: number; btcDom: number; ethDom: number; change24h: number };

const STABLES = new Set(["USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "BUSD", "USD1", "XUSD", "USDE", "AEUR", "EURI", "PAXG", "WBTC", "BFUSD", "RLUSD", "USDG"]);
const MAJORS = ["BTC", "ETH", "SOL", "XRP", "BNB", "DOGE", "ADA", "LINK", "AVAX", "SUI"];

async function getJson<T>(url: string): Promise<T | null> {
  try {
    const r = await fetch(url);
    if (!r.ok) return null;
    return (await r.json()) as T;
  } catch {
    return null;
  }
}

export async function fetchMovers(): Promise<Mover[]> {
  const bn = await getJson<{ symbol: string; lastPrice: string; priceChangePercent: string; quoteVolume: string }[]>(
    "https://data-api.binance.vision/api/v3/ticker/24hr",
  );
  const fromBinance = (Array.isArray(bn) ? bn : [])
    .filter((t) => t.symbol.endsWith("USDT") && !STABLES.has(t.symbol.replace(/USDT$/, "")) && Number(t.quoteVolume) > 5_000_000)
    .map((t) => ({ symbol: t.symbol.replace(/USDT$/, ""), price: Number(t.lastPrice), change: Number(t.priceChangePercent), volume: Number(t.quoteVolume) }));
  if (fromBinance.length) return fromBinance;

  const okx = await getJson<{ data?: { instId: string; last: string; open24h: string; volCcy24h: string }[] }>(
    "https://www.okx.com/api/v5/market/tickers?instType=SPOT",
  );
  return (okx?.data ?? [])
    .filter((t) => t.instId.endsWith("-USDT") && !STABLES.has(t.instId.replace(/-USDT$/, "")) && Number(t.volCcy24h) > 1_000_000)
    .map((t) => {
      const last = Number(t.last);
      const open = Number(t.open24h);
      return { symbol: t.instId.replace(/-USDT$/, ""), price: last, change: open ? ((last - open) / open) * 100 : 0, volume: Number(t.volCcy24h) };
    });
}

export async function fetchGlobal(): Promise<GlobalStats | null> {
  const g = await getJson<{ data: { total_market_cap: { usd: number }; total_volume: { usd: number }; market_cap_percentage: Record<string, number>; market_cap_change_percentage_24h_usd: number } }>(
    "https://api.coingecko.com/api/v3/global",
  );
  if (!g?.data) return null;
  return {
    marketCap: g.data.total_market_cap.usd,
    volume: g.data.total_volume.usd,
    btcDom: g.data.market_cap_percentage["btc"] ?? 0,
    ethDom: g.data.market_cap_percentage["eth"] ?? 0,
    change24h: g.data.market_cap_change_percentage_24h_usd,
  };
}

export function moverLists(usdt: Mover[]) {
  const sorted = [...usdt].sort((a, b) => b.change - a.change);
  return {
    gainers: sorted.slice(0, 8),
    losers: sorted.slice(-8).reverse(),
    volumeLeaders: [...usdt].sort((a, b) => b.volume - a.volume).slice(0, 8),
    majors: MAJORS.map((s) => usdt.find((m) => m.symbol === s)).filter((m): m is Mover => !!m),
  };
}
