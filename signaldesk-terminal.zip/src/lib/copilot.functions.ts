import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listCopilotThreads = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("copilot_threads")
      .select("id,title,updated_at")
      .eq("user_id", context.userId)
      .order("updated_at", { ascending: false });
    if (error) throw new Error("Could not load your conversations. Please try again.");
    return data ?? [];
  });

export const getCopilotThread = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({ threadId: z.string().uuid() }))
  .handler(async ({ data, context }) => {
    const result = await context.supabase
      .from("copilot_threads")
      .select("id,title,messages")
      .eq("id", data.threadId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (result.error) throw new Error("Could not load this conversation.");
    if (!result.data) throw new Error("This conversation was not found in your account.");
    return {
      id: result.data.id,
      title: result.data.title,
      messagesJson: JSON.stringify(Array.isArray(result.data.messages) ? result.data.messages : []),
    };
  });

export const createCopilotThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({ title: z.string().trim().min(1).max(100) }))
  .handler(async ({ data, context }) => {
    const result = await context.supabase
      .from("copilot_threads")
      .insert({ user_id: context.userId, title: data.title })
      .select("id")
      .single();
    if (result.error || !result.data)
      throw new Error("Could not create a conversation. Please try again.");
    return result.data;
  });

export const deleteCopilotThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({ threadId: z.string().uuid() }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("copilot_threads")
      .delete()
      .eq("id", data.threadId)
      .eq("user_id", context.userId);
    if (error) throw new Error("Could not delete this conversation.");
    return { ok: true };
  });

export const restoreCopilotAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase
      .from("copilot_access_blocks")
      .update({ reason: "" })
      .eq("user_id", context.userId);
    if (error) throw new Error("Could not restore access. Please try again.");
    return { ok: true };
  });
