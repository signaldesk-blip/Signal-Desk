import { z } from "zod";
import { tradeMath } from "./copilot";

export const setupModes = [
  {
    id: "ltf-long",
    label: "LTF long",
    detail: "Short term · 4-hour",
    direction: "long",
    horizon: "ltf",
  },
  {
    id: "ltf-short",
    label: "LTF short",
    detail: "Short term · 4-hour",
    direction: "short",
    horizon: "ltf",
  },
  {
    id: "htf-long",
    label: "HTF swing long",
    detail: "Swing · daily & weekly",
    direction: "long",
    horizon: "htf",
  },
  {
    id: "htf-short",
    label: "HTF swing short",
    detail: "Swing · daily & weekly",
    direction: "short",
    horizon: "htf",
  },
] as const;
export type SetupMode = (typeof setupModes)[number]["id"];
export function setupRequest(asset: string, mode: SetupMode, scan: boolean) {
  const choice = setupModes.find((item) => item.id === mode);
  if (!choice) throw new Error("Choose a setup type.");
  return `Produce up to 2 educational conditional ${choice.label} AI setup ideas ${scan ? "from current scanner candidates" : `for ${asset}`}. Direction must be ${choice.direction}. ${choice.horizon === "ltf" ? "Use 4-hour candles for short-term entries with daily/weekly context. Do not claim 15-minute or 1-hour analysis: that data is not available." : "Use daily/weekly structure for swing entries, stops and targets; 4-hour candles are only for confirmation."} Check timestamped marketData first. Present each valid idea through presentSetup: just asset, direction, timeframe, entry, stop, target and calculated reward-to-risk at the top; a short plain-English explanation below. Include brief confirmation, invalidation, opposing evidence and expiry. Do not write a lengthy report or duplicate the figures in prose. Say no clear setup if evidence is weak; do not invent prices or win probabilities.`;
}

export const setupIdeaSchema = z.object({
  asset: z.string(),
  direction: z.enum(["long", "short"]),
  timeframe: z.string(),
  entry: z.number(),
  stop: z.number(),
  target: z.number(),
  confirmation: z.string(),
  explanation: z.string(),
  opposingEvidence: z.string(),
  invalidation: z.string(),
  expiresAt: z.string(),
});
export type SetupIdea = z.infer<typeof setupIdeaSchema> & {
  rewardToRisk: number;
  checkedAt: string;
};
export function calculateSetup(
  input: z.infer<typeof setupIdeaSchema>,
  checkedAt: string,
): SetupIdea {
  const math = tradeMath({ ...input, reasoning: input.explanation });
  return { ...input, rewardToRisk: math.rewardToRisk, checkedAt };
}
