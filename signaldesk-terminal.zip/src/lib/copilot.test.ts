import { describe, expect, it } from "vitest";
import { tradeMath, tradeChallengeSchema } from "./copilot";

const example = {
  asset: "SOL",
  direction: "long" as const,
  entry: 100,
  stop: 92,
  target: 160,
  reasoning: "Demand zone",
};
describe("Trade challenge mathematics", () => {
  it("calculates SOL 100 / 92 / 160 as 7.5 reward to risk", () => {
    expect(tradeMath(example)).toEqual({
      risk: 8,
      reward: 60,
      rewardToRisk: 7.5,
      breakEvenWinRatePct: (8 / 68) * 100,
    });
  });
  it("calculates short trade direction correctly", () => {
    expect(tradeMath({ ...example, direction: "short", stop: 108, target: 40 }).rewardToRisk).toBe(
      7.5,
    );
  });
  it("rejects inverted stops and targets", () => {
    expect(tradeChallengeSchema.safeParse({ ...example, stop: 105 }).success).toBe(false);
    expect(tradeChallengeSchema.safeParse({ ...example, direction: "short" }).success).toBe(false);
  });
  it("rejects zero-risk and non-positive price inputs", () => {
    expect(tradeChallengeSchema.safeParse({ ...example, stop: 100 }).success).toBe(false);
    expect(tradeChallengeSchema.safeParse({ ...example, entry: 0 }).success).toBe(false);
  });
});
