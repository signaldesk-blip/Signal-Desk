// Real open interest (USD) from OKX public stats — all OKX contracts for the coin.
export type OIPoint = { time: number; usd: number };
export type OIData = { "1h": OIPoint[]; "1d": OIPoint[]; latestUsd: number; change24hPct: number | null; change7dPct: number | null };

const cache = new Map<string, { at: number; v: OIData }>();

async function series(ccy: string, period: "1H" | "1D"): Promise<OIPoint[]> {
  const r = await fetch(`https://www.okx.com/api/v5/rubik/stat/contracts/open-interest-volume?ccy=${ccy}&period=${period}`);
  if (!r.ok) throw new Error(`OKX OI ${r.status}`);
  const j = (await r.json()) as { code: string; data?: string[][] };
  if (j.code !== "0" || !j.data?.length) throw new Error("no OI");
  return j.data.map((row) => ({ time: Math.floor(Number(row[0]) / 1000), usd: Number(row[1]) })).filter((p) => p.usd > 0).sort((a, b) => a.time - b.time);
}

export async function getOpenInterest(ticker: string): Promise<OIData | null> {
  const hit = cache.get(ticker);
  if (hit && Date.now() - hit.at < 5 * 60_000) return hit.v;
  try {
    const [h, d] = await Promise.all([series(ticker, "1H"), series(ticker, "1D")]);
    const latest = h[h.length - 1]?.usd ?? d[d.length - 1]?.usd ?? 0;
    const ago = (pts: OIPoint[], n: number) => pts[pts.length - 1 - n]?.usd;
    const pct = (a?: number) => (a ? ((latest - a) / a) * 100 : null);
    const v: OIData = { "1h": h, "1d": d, latestUsd: latest, change24hPct: pct(ago(h, 24)), change7dPct: pct(ago(d, 7)) };
    cache.set(ticker, { at: Date.now(), v });
    return v;
  } catch {
    return hit?.v ?? null;
  }
}

export function oiSummary(o: OIData | null): string {
  if (!o) return "Open interest: no live data available — do not invent figures.";
  const f = (n: number | null) => (n == null ? "n/a" : `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`);
  const last = o["1d"].slice(-14).map((p) => `${new Date(p.time * 1000).toISOString().slice(0, 10)} $${(p.usd / 1e6).toFixed(0)}M`).join(", ");
  return `Open interest (OKX, real): now $${(o.latestUsd / 1e6).toFixed(0)}M, 24h ${f(o.change24hPct)}, 7d ${f(o.change7dPct)}. Daily: ${last}`;
}
