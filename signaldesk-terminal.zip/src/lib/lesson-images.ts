import lesson0 from "@/assets/lessons/what-is-bitcoin.jpg";
import lesson1 from "@/assets/lessons/what-is-blockchain.jpg";
import lesson2 from "@/assets/lessons/what-are-altcoins.jpg";
import lesson3 from "@/assets/lessons/what-is-an-exchange.jpg";
import lesson4 from "@/assets/lessons/what-is-a-wallet.jpg";
import lesson5 from "@/assets/lessons/spot-vs-futures.jpg";
import lesson6 from "@/assets/lessons/candlestick-charts.jpg";
import lesson7 from "@/assets/lessons/support-and-resistance.jpg";
import lesson8 from "@/assets/lessons/market-structure.jpg";
import lesson9 from "@/assets/lessons/supply-and-demand.jpg";
import lesson10 from "@/assets/lessons/trading-volume.jpg";
import lesson11 from "@/assets/lessons/market-capitalisation.jpg";
import lesson12 from "@/assets/lessons/liquidity.jpg";
import lesson13 from "@/assets/lessons/risk-to-reward.jpg";
import lesson14 from "@/assets/lessons/position-sizing.jpg";
import lesson15 from "@/assets/lessons/stop-losses.jpg";
import lesson16 from "@/assets/lessons/leverage-and-liquidation.jpg";
import lesson17 from "@/assets/lessons/trading-psychology.jpg";
import lesson18 from "@/assets/lessons/trading-plan.jpg";
import lesson19 from "@/assets/lessons/open-interest-funding.jpg";
import lesson20 from "@/assets/lessons/liquidation-heatmaps.jpg";
import lesson21 from "@/assets/lessons/volume-profile.jpg";
import lesson22 from "@/assets/lessons/macroeconomic-analysis.jpg";
import lesson23 from "@/assets/lessons/multi-timeframe-analysis.jpg";
import lesson24 from "@/assets/lessons/portfolio-risk-management.jpg";

export const LESSON_IMAGES: Record<string, string> = {
  "what-is-bitcoin": lesson0,
  "what-is-blockchain": lesson1,
  "what-are-altcoins": lesson2,
  "what-is-an-exchange": lesson3,
  "what-is-a-wallet": lesson4,
  "spot-vs-futures": lesson5,
  "candlestick-charts": lesson6,
  "support-and-resistance": lesson7,
  "market-structure": lesson8,
  "supply-and-demand": lesson9,
  "trading-volume": lesson10,
  "market-capitalisation": lesson11,
  "liquidity": lesson12,
  "risk-to-reward": lesson13,
  "position-sizing": lesson14,
  "stop-losses": lesson15,
  "leverage-and-liquidation": lesson16,
  "trading-psychology": lesson17,
  "trading-plan": lesson18,
  "open-interest-funding": lesson19,
  "liquidation-heatmaps": lesson20,
  "volume-profile": lesson21,
  "macroeconomic-analysis": lesson22,
  "multi-timeframe-analysis": lesson23,
  "portfolio-risk-management": lesson24,
};
