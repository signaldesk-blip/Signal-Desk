// Real US macro data from FRED's public CSV downloads (no key needed).
export type MacroStat = { key: string; label: string; value: number; previous: number | null; unit: string; date: string; note: string };

const SERIES = [
  { key: "CPI", id: "CPIAUCSL", label: "Inflation (CPI, yearly)", unit: "%", yoy: true, note: "Higher inflation usually means rates stay high — tough for crypto." },
  { key: "CORE", id: "CPILFESL", label: "Core inflation (yearly)", unit: "%", yoy: true, note: "Inflation without food & energy — what the Fed watches most." },
  { key: "RATE", id: "DFF", label: "Fed interest rate", unit: "%", yoy: false, note: "Lower rates tend to push money into riskier assets like crypto." },
  { key: "UNEMP", id: "UNRATE", label: "Unemployment", unit: "%", yoy: false, note: "Rising unemployment can lead the Fed to cut rates." },
  { key: "GDP", id: "A191RL1Q225SBEA", label: "GDP growth (quarterly, annualised)", unit: "%", yoy: false, note: "How fast the US economy is growing." },
  { key: "US10Y", id: "DGS10", label: "10-year Treasury yield", unit: "%", yoy: false, note: "Rising yields pull money away from risk assets." },
] as const;

let cache: { at: number; v: MacroStat[] } | null = null;

async function csv(id: string): Promise<{ date: string; v: number }[]> {
  const r = await fetch(`https://fred.stlouisfed.org/graph/fredgraph.csv?id=${id}`, { headers: { "User-Agent": "Mozilla/5.0 SignalDesk" } });
  if (!r.ok) throw new Error(`FRED ${id} ${r.status}`);
  return (await r.text()).trim().split("\n").slice(1).map((l) => { const [d, v] = l.split(","); return { date: d ?? "", v: Number(v) }; }).filter((p) => p.date && Number.isFinite(p.v));
}

export async function getMacro(): Promise<MacroStat[]> {
  if (cache && Date.now() - cache.at < 6 * 3600_000) return cache.v;
  const out = await Promise.all(SERIES.map(async (s) => {
    try {
      const rows = await csv(s.id);
      const n = rows.length;
      if (!n) return null;
      if (s.yoy) {
        const y = (i: number) => { const a = rows[i], b = rows[i - 12]; return a && b ? ((a.v - b.v) / b.v) * 100 : null; };
        const v = y(n - 1);
        if (v == null) return null;
        return { key: s.key, label: s.label, unit: s.unit, note: s.note, value: v, previous: y(n - 2), date: rows[n - 1]!.date };
      }
      // Daily series: compare to ~1 month back for "previous".
      const back = s.id === "DFF" || s.id === "DGS10" ? 22 : 1;
      return { key: s.key, label: s.label, unit: s.unit, note: s.note, value: rows[n - 1]!.v, previous: rows[n - 1 - back]?.v ?? null, date: rows[n - 1]!.date };
    } catch {
      return cache?.v.find((c) => c.key === s.key) ?? null;
    }
  }));
  const v = out.filter((x): x is MacroStat => !!x);
  if (v.length) cache = { at: Date.now(), v };
  return v;
}
