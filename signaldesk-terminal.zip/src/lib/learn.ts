// Structured learning path — plain-English lessons, no jargon left unexplained.

export interface Lesson {
  id: string;
  title: string;
  minutes: number;
  body: string[]; // paragraphs
  keyPoints: string[];
}

export interface Level {
  id: string;
  title: string;
  tagline: string;
  lessons: Lesson[];
}

export const LEVELS: Level[] = [
  {
    id: "level-1",
    title: "Level 1 — Understanding Crypto",
    tagline: "The absolute basics. Start here if crypto is new to you.",
    lessons: [
      {
        id: "what-is-bitcoin",
        title: "What is Bitcoin?",
        minutes: 4,
        body: [
          "Bitcoin is digital money that isn't controlled by any bank or government. It was created in 2009 by a person (or group) using the name Satoshi Nakamoto, after the financial crisis shook trust in banks.",
          "Instead of a bank keeping track of who owns what, Bitcoin uses a public record shared across thousands of computers worldwide. No single party can change it, print more of it, or freeze your account.",
          "There will only ever be 21 million bitcoins. That fixed supply is why people compare it to gold — it's scarce, and no government can create more of it.",
          "People buy Bitcoin for different reasons: some see it as a long-term store of value ('digital gold'), some use it to send money across borders cheaply, and some trade it hoping the price rises.",
        ],
        keyPoints: [
          "Digital money with no bank or government in charge",
          "A public record keeps track of every coin",
          "Only 21 million will ever exist",
          "Often compared to gold because it's scarce",
        ],
      },
      {
        id: "what-is-blockchain",
        title: "What is blockchain?",
        minutes: 4,
        body: [
          "A blockchain is the record-keeping system behind Bitcoin and other cryptocurrencies. Think of it as a shared notebook that thousands of computers keep an identical copy of.",
          "Transactions are grouped into 'blocks'. Each new block is linked to the one before it, forming a chain — hence 'blockchain'. Once something is written into the chain, changing it would require rewriting every copy on thousands of computers at once, which is practically impossible.",
          "This is what makes crypto work without a bank: instead of trusting one company to keep honest records, everyone can check the shared record themselves.",
          "Blockchains are used for more than money — tracking goods, proving ownership of digital items, and running programs called 'smart contracts' — but their first and biggest use is cryptocurrency.",
        ],
        keyPoints: [
          "A shared record kept by thousands of computers",
          "Transactions are grouped into blocks, linked in a chain",
          "Extremely hard to tamper with",
          "Removes the need to trust a single company",
        ],
      },
      {
        id: "what-are-altcoins",
        title: "What are altcoins?",
        minutes: 3,
        body: [
          "'Altcoin' simply means any cryptocurrency that isn't Bitcoin. There are thousands of them, and they vary enormously in quality and purpose.",
          "Some, like Ethereum, do things Bitcoin doesn't — Ethereum can run programs ('smart contracts') that power apps, games and financial services. Others, like Litecoin, are mostly variations on Bitcoin's idea.",
          "Many altcoins are much smaller and riskier than Bitcoin. Their prices can swing wildly, and some projects fail completely. A well-known name and a large market value are signs of a more established coin, but never a guarantee.",
          "A common rule of thumb: the smaller and newer the coin, the more it behaves like a lottery ticket rather than an investment.",
        ],
        keyPoints: [
          "Any crypto that isn't Bitcoin is an altcoin",
          "Some add new features (e.g. Ethereum's smart contracts)",
          "Smaller coins are usually much riskier",
          "Many projects fail — research before buying",
        ],
      },
      {
        id: "what-is-an-exchange",
        title: "What is a crypto exchange?",
        minutes: 4,
        body: [
          "A crypto exchange is a website or app where you buy, sell and trade cryptocurrencies — similar to an online stockbroker.",
          "You deposit regular money (like pounds or dollars) by bank transfer or card, then use it to buy crypto. The exchange holds your coins in an account until you sell them or move them to your own wallet.",
          "Well-known exchanges include Coinbase, Kraken and Binance. They differ in fees, the coins they offer, and how beginner-friendly they are.",
          "Two things to know: exchanges charge fees on every trade, and if an exchange is hacked or goes bust, coins kept on it can be lost. That's why many people move larger amounts to their own wallet (covered in the next lesson).",
        ],
        keyPoints: [
          "An exchange is where you buy and sell crypto",
          "You deposit normal money, then trade it for coins",
          "Exchanges charge fees on trades",
          "Coins left on an exchange carry some risk",
        ],
      },
      {
        id: "what-is-a-wallet",
        title: "What is a wallet?",
        minutes: 4,
        body: [
          "A crypto wallet stores the keys that prove you own your coins. The coins themselves always live on the blockchain — the wallet is what lets you access and spend them.",
          "There are two main types. A 'hot wallet' is an app or website connected to the internet — convenient, but more exposed to hackers. A 'cold wallet' is a small physical device (like a USB stick) kept offline — the safest option for larger amounts.",
          "Every wallet has a 'recovery phrase': a list of 12 or 24 words that can restore your wallet if you lose your phone or device. Whoever has those words controls your coins.",
          "Golden rules: never share your recovery phrase with anyone, never type it into a website, and write it down on paper — not on your phone or computer. No legitimate company will ever ask for it.",
        ],
        keyPoints: [
          "A wallet holds the keys to your coins",
          "Hot wallets are online; cold wallets are offline and safer",
          "Your recovery phrase controls everything — guard it",
          "Never share the phrase or type it into a website",
        ],
      },
      {
        id: "spot-vs-futures",
        title: "Spot vs futures trading",
        minutes: 5,
        body: [
          "Spot trading is the simple kind: you buy a coin, you own it, and you can sell it whenever you like. If the price goes up 10%, you make 10%. If it falls 10%, you lose 10%.",
          "Futures trading is a bet on where the price will go, without owning the coin. You can bet on the price rising ('going long') or falling ('going short').",
          "Futures also allow 'leverage' — borrowing to multiply your bet. With 10x leverage, a 5% price move becomes a 50% gain… or a 50% loss. If the price moves far enough against you, the exchange closes your position and you lose your entire stake. This is called liquidation.",
          "Most beginners should stick to spot. The majority of people who trade futures with leverage lose money — the statistics from exchanges and regulators are very clear on this.",
        ],
        keyPoints: [
          "Spot = buying and owning the actual coin",
          "Futures = betting on the price, long or short",
          "Leverage multiplies both gains and losses",
          "Leveraged trading wipes out most beginners",
        ],
      },
    ],
  },
  {
    id: "level-2",
    title: "Level 2 — Understanding Markets",
    tagline: "How to read a chart and understand what prices are telling you.",
    lessons: [
      {
        id: "candlestick-charts",
        title: "Candlestick charts",
        minutes: 5,
        body: [
          "A candlestick chart is the standard way traders view prices. Each 'candle' shows what the price did during one period — one hour, one day, one week, depending on the chart.",
          "Each candle has a body and two thin lines called wicks. The body shows where the price started and ended the period. The wicks show the highest and lowest prices reached in between.",
          "A green candle means the price went up during that period (it closed higher than it opened). A red candle means it went down.",
          "Candles tell a story. A long green candle shows strong buying. A small body with long wicks shows a battle between buyers and sellers with no clear winner. Learning to read these shapes is the foundation of chart analysis — and it's exactly what the charts on this site show you.",
        ],
        keyPoints: [
          "Each candle shows one time period",
          "Body = open to close; wicks = the extremes",
          "Green = price rose, red = price fell",
          "Candle shapes reveal who won: buyers or sellers",
        ],
      },
      {
        id: "support-and-resistance",
        title: "Support and resistance",
        minutes: 5,
        body: [
          "Support is a price level where falling prices tend to stop and bounce — because buyers see it as cheap and step in. Think of it as a floor.",
          "Resistance is the opposite: a ceiling where rising prices tend to stall, because sellers take profits and buyers get cautious.",
          "These levels exist because people remember them. If Bitcoin bounced off $60,000 twice before, traders watching the same chart will place buy orders there again — making the level work a third time.",
          "When a price breaks decisively through a level, roles often flip: an old ceiling becomes a new floor. The AI Chart Analyst on this site marks these levels on the chart for you automatically.",
        ],
        keyPoints: [
          "Support = a floor where buyers step in",
          "Resistance = a ceiling where sellers step in",
          "Levels work because many traders watch the same ones",
          "Broken ceilings often become new floors",
        ],
      },
      {
        id: "market-structure",
        title: "Market structure",
        minutes: 5,
        body: [
          "Markets move in waves, not straight lines. Market structure is the pattern those waves make — and it tells you the direction of the trend.",
          "In an uptrend, each wave makes a higher high and a higher low: the price steps upwards like a staircase. In a downtrend it's the reverse — lower highs and lower lows.",
          "The trend is your friend until it isn't. When an uptrend stops making higher highs and instead breaks below its last low, the structure has 'broken' — an early warning that the trend may be reversing.",
          "A simple habit: before looking at anything else, ask 'is this chart making higher highs, or lower highs?' That one question tells you whether to be looking to buy or to be cautious.",
        ],
        keyPoints: [
          "Uptrend = higher highs and higher lows",
          "Downtrend = lower highs and lower lows",
          "A break in the pattern warns of a possible reversal",
          "Always check the trend direction first",
        ],
      },
      {
        id: "supply-and-demand",
        title: "Supply and demand",
        minutes: 5,
        body: [
          "Supply and demand zones are areas on the chart where big buying or selling previously overwhelmed the other side — often because large players (funds, institutions) were active there.",
          "A demand zone is an area where strong buying pushed the price up sharply. When the price returns to that area, those buyers (or others like them) often step in again. On this site's charts, demand zones are shaded green.",
          "A supply zone is the opposite: an area where heavy selling pushed the price down hard. When the price climbs back into it, selling often resumes. These are shaded red.",
          "Zones are areas, not exact lines — prices rarely turn at a precise penny. That's why the AI analyst draws them as bands rather than single lines, and why wider zones on the weekly chart matter more than narrow ones on the 4-hour chart.",
        ],
        keyPoints: [
          "Zones mark where big buyers or sellers were active",
          "Demand zone = buying area (green on our charts)",
          "Supply zone = selling area (red on our charts)",
          "Zones are bands, not exact prices",
        ],
      },
      {
        id: "trading-volume",
        title: "Trading volume",
        minutes: 4,
        body: [
          "Volume shows how much of a coin changed hands in each period — the bars along the bottom of the chart. It tells you how much conviction is behind a price move.",
          "A price rise on high volume means lots of buyers genuinely committed money — the move is more likely to continue. A rise on low volume is weaker and more likely to fade.",
          "Volume spikes often mark turning points. A huge burst of selling after a long fall can signal 'capitulation' — the last frightened sellers giving up, often near a bottom.",
          "A useful rule: price tells you what happened, volume tells you whether to believe it.",
        ],
        keyPoints: [
          "Volume = how much was traded",
          "Big moves on big volume are more trustworthy",
          "Moves on low volume often fade",
          "Volume spikes can mark turning points",
        ],
      },
      {
        id: "market-capitalisation",
        title: "Market capitalisation",
        minutes: 4,
        body: [
          "Market capitalisation ('market cap') is the total value of all a coin's coins: the price multiplied by the number of coins in existence.",
          "It matters more than the price per coin. A coin priced at $0.01 is not 'cheap' if there are a trillion of them — its total value could be enormous. Comparing market caps is the fair way to compare coins.",
          "Large-cap coins (Bitcoin, Ethereum) tend to move more slowly and steadily. Small-cap coins can multiply quickly but can also collapse just as fast — and are easier for big players to manipulate.",
          "You'll see total market cap and Bitcoin's share of it ('dominance') on this site's homepage. When Bitcoin dominance rises, money is flowing to safety; when it falls, traders are taking risks on smaller coins.",
        ],
        keyPoints: [
          "Market cap = price × number of coins",
          "Compare coins by market cap, not coin price",
          "Big caps are steadier; small caps are wilder",
          "Bitcoin dominance shows the market's mood",
        ],
      },
      {
        id: "liquidity",
        title: "Liquidity",
        minutes: 4,
        body: [
          "Liquidity means how easily you can buy or sell something without moving its price. A liquid market has lots of buyers and sellers at all times.",
          "Bitcoin is very liquid: you can sell a large amount in seconds at a fair price. A small, obscure coin may be so illiquid that selling even a modest amount crashes the price — or that there's no buyer at all when you want out.",
          "Low liquidity also means bigger, jumpier price moves, because a single large order can shove the price around.",
          "Practical takeaway: stick to coins with high trading volume, especially while learning. The top movers lists on the homepage show which coins are trading most actively.",
        ],
        keyPoints: [
          "Liquidity = ease of buying/selling without moving the price",
          "Bitcoin is highly liquid; small coins often aren't",
          "Low liquidity means jumpier, riskier prices",
          "Favour high-volume coins while learning",
        ],
      },
    ],
  },
  {
    id: "level-3",
    title: "Level 3 — Becoming a Better Trader",
    tagline: "The skills that decide whether you keep your money.",
    lessons: [
      {
        id: "risk-to-reward",
        title: "Risk-to-reward ratios",
        minutes: 5,
        body: [
          "Before any trade, ask: how much am I risking, and how much do I stand to make? That comparison is the risk-to-reward ratio.",
          "If you risk $100 to potentially make $300, that's a 1:3 ratio. With 1:3 trades, you can be wrong most of the time and still come out ahead — three losing trades (-$300) are covered by a single winner (+$300).",
          "This is the single most important idea in trading. Most beginners focus on being right; professionals focus on making sure their winners are much bigger than their losers.",
          "The trading journal on this site calculates your risk-to-reward automatically when you log a trade with an entry, stop and target — so you can see whether your trades are worth taking before you take them.",
        ],
        keyPoints: [
          "Compare what you risk with what you could make",
          "1:3 means you can lose often and still profit",
          "Winners must be bigger than losers",
          "The journal works this out for you",
        ],
      },
      {
        id: "position-sizing",
        title: "Position sizing",
        minutes: 5,
        body: [
          "Position sizing means deciding how much money to put into each trade. Get this wrong and nothing else matters — a few oversized losses can wipe out an account.",
          "A common professional rule: risk no more than 1–2% of your total money on any single trade. If you have £5,000, that means a maximum loss of £50–£100 per trade.",
          "Note that 'risk' means the amount you'd lose if your stop-loss is hit — not the total amount you invest. With a stop-loss 5% below your entry, risking £50 means buying £1,000 worth.",
          "With 1% risk per trade, you could lose ten trades in a row and still have 90% of your money. That staying power is what lets you survive long enough to learn.",
        ],
        keyPoints: [
          "Never risk more than 1–2% per trade",
          "Risk = what you lose if your stop is hit",
          "Small risks let you survive losing streaks",
          "Survival comes before profits",
        ],
      },
      {
        id: "stop-losses",
        title: "Stop-losses and invalidation",
        minutes: 5,
        body: [
          "A stop-loss is an automatic order that sells your position if the price falls to a level you choose. It's your safety net — it caps the damage when a trade goes wrong.",
          "The right place for a stop is where your reason for the trade is proven wrong — 'invalidated'. If you bought because a support level should hold, your stop belongs below that support: if it breaks, your idea was wrong and you should be out.",
          "Placing stops too close is a common mistake — normal price wiggles knock you out before the trade has a chance. Placing them at a logical level and sizing the position so the loss is affordable is the professional approach.",
          "Never move a stop further away to avoid a loss. Taking a small, planned loss is a good trade; hoping a bad trade recovers is how small losses become disasters.",
        ],
        keyPoints: [
          "A stop-loss caps your loss automatically",
          "Place it where your trade idea is proven wrong",
          "Too-tight stops get hit by normal noise",
          "Never widen a stop to avoid a loss",
        ],
      },
      {
        id: "leverage-and-liquidation",
        title: "Leverage and liquidation",
        minutes: 5,
        body: [
          "Leverage means trading with borrowed money to multiply your position. With 10x leverage, £100 controls £1,000 worth of crypto.",
          "The catch: losses are multiplied too. With 10x leverage, a 10% move against you wipes out your entire £100. The exchange automatically closes your position at that point — this is liquidation, and your money is gone.",
          "Liquidations matter to everyone, even spot holders. When many leveraged traders get liquidated at once, their forced selling cascades and can crash the price for everyone. That's why this site shows real liquidation data on the charts — clusters of liquidations mark prices where forced buying or selling hit the market.",
          "If you take one rule from this course: don't use leverage while learning. The overwhelming majority of leveraged beginners lose their stake.",
        ],
        keyPoints: [
          "Leverage multiplies gains and losses",
          "Liquidation = the exchange closes your position, stake lost",
          "Liquidation cascades move the whole market",
          "Avoid leverage while learning",
        ],
      },
      {
        id: "trading-psychology",
        title: "Trading psychology",
        minutes: 5,
        body: [
          "The hardest part of trading isn't reading charts — it's managing yourself. Fear and greed cause most trading losses, not bad analysis.",
          "Common traps: FOMO (buying after a big rise because you fear missing out — usually near the top), revenge trading (rushing into a new trade to win back a loss), and holding losers too long because selling means admitting a mistake.",
          "Good traders are boring. They decide their entry, stop and target before entering, then follow the plan regardless of how they feel. The plan is made with a clear head; feelings mid-trade are almost always wrong.",
          "Practical defences: risk small amounts (fear shrinks when the money at stake doesn't matter to you), keep a journal of every trade and why you took it, and take breaks after losses.",
        ],
        keyPoints: [
          "Fear and greed cause most losses",
          "FOMO and revenge trading are the classic traps",
          "Plan the trade, then follow the plan",
          "Small positions keep emotions small",
        ],
      },
      {
        id: "trading-plan",
        title: "Building a trading plan",
        minutes: 5,
        body: [
          "A trading plan is a written set of rules you follow every time. It removes on-the-spot decisions, which are where emotions do their damage.",
          "A simple plan answers five questions before every trade: What am I buying and why? Where do I enter? Where is my stop-loss (where am I wrong)? Where is my target? How much am I risking?",
          "If you can't answer all five, you don't have a trade — you have a gamble. Write the answers down. The journal on this site is built exactly for this: entry, stop, target and size for every trade.",
          "Review your journal weekly. Look for patterns: which setups worked, which mistakes repeat. Improving one repeated mistake at a time is how traders actually get better.",
        ],
        keyPoints: [
          "A plan is written rules, decided in advance",
          "Five questions: what, why, entry, stop, size",
          "No plan = gambling",
          "Review your journal weekly and fix one mistake at a time",
        ],
      },
    ],
  },
  {
    id: "level-4",
    title: "Level 4 — Advanced Market Analysis",
    tagline: "The tools professionals watch — the same ones this site tracks for you.",
    lessons: [
      {
        id: "open-interest-funding",
        title: "Open interest and funding rates",
        minutes: 6,
        body: [
          "Open interest is the total value of open futures bets in the market. Rising open interest means new money is piling in; falling open interest means positions are being closed.",
          "The combination with price is what matters. Price up + open interest up = new buyers entering (healthy trend). Price up + open interest down = short sellers being squeezed out (weaker rally). Price down + open interest up = new shorts piling in. The AI analyst on this site reads this for you and shows the open interest line under the chart.",
          "Funding rates are small payments between futures traders that keep futures prices in line with spot. When funding is strongly positive, longs are paying shorts — the crowd is betting heavily on rises, often a warning sign of overconfidence. Strongly negative funding means the crowd is betting on falls.",
          "Extreme funding in either direction often precedes a move the other way, because one-sided crowds get liquidated. It's a contrarian indicator at the extremes.",
        ],
        keyPoints: [
          "Open interest = total open futures bets",
          "Price + OI together reveal the trend's health",
          "Funding shows which way the crowd is leaning",
          "Extreme funding often precedes a reversal",
        ],
      },
      {
        id: "liquidation-heatmaps",
        title: "Liquidation heatmaps",
        minutes: 5,
        body: [
          "A liquidation heatmap shows where large clusters of leveraged positions would be force-closed if the price reached them. These clusters act like magnets.",
          "Why? When liquidations trigger, they become forced market orders — a cascade of selling (or buying) that pushes the price further in the same direction. Big players know where these clusters sit and sometimes push the price towards them deliberately ('hunting liquidity').",
          "This is why prices often spike sharply to a level, trigger a burst of liquidations, and then reverse — the move had no genuine buyers or sellers behind it, just forced ones.",
          "This site shows real liquidation data from OKX as dotted lines on the chart. Where you see recent liquidation clusters, the market has already been through a flush; the AI analyst factors this into its read of the market.",
        ],
        keyPoints: [
          "Heatmaps show where liquidations cluster",
          "Clusters act like price magnets",
          "Liquidation cascades cause sharp spikes and reversals",
          "Our charts show real liquidation lines from OKX",
        ],
      },
      {
        id: "volume-profile",
        title: "Volume profile",
        minutes: 5,
        body: [
          "Regular volume bars show how much traded per time period. Volume profile flips it: it shows how much traded at each price level, drawn as horizontal bars along the side of the chart.",
          "Prices where huge volume traded are 'accepted' levels — the market spent real money there, so they tend to act as strong support or resistance. Prices with little volume are 'rejected' — the price tends to move through them quickly.",
          "The price with the most volume of all is called the 'point of control' — the fairest price the market agreed on. Prices often get pulled back towards it.",
          "Volume profile explains why some support levels hold like concrete and others slice through like paper: it's the amount of real trading done there that counts.",
        ],
        keyPoints: [
          "Volume profile shows volume per price, not per time",
          "High-volume prices act as strong support/resistance",
          "Low-volume prices get sliced through quickly",
          "The point of control is the market's 'fairest' price",
        ],
      },
      {
        id: "macroeconomic-analysis",
        title: "Macroeconomic analysis",
        minutes: 6,
        body: [
          "Crypto doesn't move in a vacuum. Since 2020 especially, it has traded like a 'risk asset' — rising when money is cheap and plentiful, falling when money is tight.",
          "The big drivers: interest rates (higher rates make safe savings more attractive and drain money from risky assets), inflation (high inflation pushes central banks to raise rates), and economic growth (recessions make investors sell risky things first).",
          "The US Federal Reserve matters most — its rate decisions and statements move every market on earth, crypto included. Key dates: Fed meetings, inflation (CPI) releases, and jobs reports.",
          "This is why the homepage of this site has an economic calendar and live US figures for inflation, rates, unemployment and GDP. Before blaming a coin's chart for a bad week, check whether the whole market was reacting to a rate decision.",
        ],
        keyPoints: [
          "Crypto trades as a risk asset",
          "Interest rates and inflation are the big drivers",
          "Fed meetings, CPI and jobs reports move everything",
          "Check the homepage calendar before big decisions",
        ],
      },
      {
        id: "multi-timeframe-analysis",
        title: "Multi-timeframe analysis",
        minutes: 5,
        body: [
          "The same coin can look bullish on one timeframe and bearish on another. A pullback on the daily chart might be a full downtrend on the 1-hour chart. Both are true at once.",
          "The professional habit: start big, then zoom in. Check the weekly chart for the overall trend, the daily for key levels, and only then the 4-hour for timing. Trade in the direction of the bigger trend.",
          "Levels from higher timeframes are stronger. A support level visible on the weekly chart has months of traders watching it; a level only visible on the 15-minute chart barely matters.",
          "This is exactly why the AI Chart Analyst analyses the weekly, daily and 4-hour charts separately and marks different zones for each — flip between the timeframes on the chart and watch the zones change.",
        ],
        keyPoints: [
          "Trends differ across timeframes — all true at once",
          "Start weekly, then daily, then 4-hour",
          "Higher-timeframe levels are stronger",
          "Trade with the bigger trend",
        ],
      },
      {
        id: "portfolio-risk-management",
        title: "Portfolio risk management",
        minutes: 6,
        body: [
          "Risk management at the portfolio level means thinking about all your holdings together, not trade by trade.",
          "Diversification in crypto is weaker than it looks: most coins move with Bitcoin, so holding ten different coins is often one big bet, not ten small ones. True diversification means not having all your wealth in crypto at all.",
          "Decide in advance what share of your total savings crypto should be — for most people, a small single-digit percentage. Within crypto, decide how much is long-term holding versus active trading, and keep them in separate accounts or wallets so a bad trading week can't touch your long-term holdings.",
          "Finally, plan for the extremes. Crypto has fallen 70–80% several times in its history. If a drop like that would force you to sell or affect your life, your position is too big — whatever the charts say.",
        ],
        keyPoints: [
          "Manage risk across your whole portfolio",
          "Crypto coins mostly move together — limited diversification",
          "Keep long-term holdings separate from trading money",
          "Size your total crypto so a 70% crash is survivable",
        ],
      },
    ],
  },
];

export const ALL_LESSONS = LEVELS.flatMap((l) => l.lessons);
