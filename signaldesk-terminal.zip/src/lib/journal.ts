export type Direction = "long" | "short";
export type TradeLike = { direction: Direction; entry: number; stop: number; target: number; exit_price: number | null; status: string; size: number | null };

/** Planned reward-to-risk ratio, e.g. 2 means the target is twice as far as the stop. */
export function plannedRR(t: Pick<TradeLike, "entry" | "stop" | "target">): number | null {
  const risk = Math.abs(t.entry - t.stop);
  return risk ? Math.abs(t.target - t.entry) / risk : null;
}

/** Result in R (multiples of risk) for a closed trade. */
export function resultR(t: TradeLike): number | null {
  if (t.status === "open" || t.exit_price == null) return null;
  const risk = Math.abs(t.entry - t.stop);
  if (!risk) return null;
  const move = t.direction === "long" ? t.exit_price - t.entry : t.entry - t.exit_price;
  return move / risk;
}

/** Profit/loss in $ when a position size (units of the coin) is given. */
export function resultUsd(t: TradeLike): number | null {
  if (t.status === "open" || t.exit_price == null || !t.size) return null;
  return (t.direction === "long" ? t.exit_price - t.entry : t.entry - t.exit_price) * t.size;
}

export function journalStats(trades: TradeLike[]) {
  const closed = trades.filter((t) => t.status !== "open");
  const wins = closed.filter((t) => t.status === "win").length;
  const rs = closed.map(resultR).filter((r): r is number => r != null);
  const usd = closed.map(resultUsd).filter((r): r is number => r != null);
  return {
    total: trades.length,
    open: trades.length - closed.length,
    closed: closed.length,
    winRate: closed.length ? (wins / closed.length) * 100 : null,
    totalR: rs.reduce((a, b) => a + b, 0),
    avgR: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : null,
    totalUsd: usd.reduce((a, b) => a + b, 0),
  };
}
