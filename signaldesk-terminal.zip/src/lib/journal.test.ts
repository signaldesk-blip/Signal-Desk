import { describe, expect, it } from "vitest";
import { journalStats, plannedRR, resultR, resultUsd } from "./journal";

const base = { size: null, exit_price: null, status: "open" };

describe("journal maths", () => {
  it("planned R:R for a long", () => {
    expect(plannedRR({ entry: 100, stop: 90, target: 130 })).toBe(3);
  });
  it("closed long result in R", () => {
    expect(resultR({ ...base, direction: "long", entry: 100, stop: 90, target: 130, exit_price: 120, status: "win" })).toBe(2);
  });
  it("closed short loss in R and $", () => {
    const t = { direction: "short" as const, entry: 100, stop: 110, target: 80, exit_price: 110, status: "loss", size: 2 };
    expect(resultR(t)).toBe(-1);
    expect(resultUsd(t)).toBe(-20);
  });
  it("win rate ignores open trades", () => {
    const s = journalStats([
      { ...base, direction: "long", entry: 100, stop: 90, target: 120, exit_price: 120, status: "win" },
      { ...base, direction: "long", entry: 100, stop: 90, target: 120, exit_price: 90, status: "loss" },
      { ...base, direction: "long", entry: 100, stop: 90, target: 120 },
    ]);
    expect(s.winRate).toBe(50);
    expect(s.totalR).toBe(1);
    expect(s.open).toBe(1);
  });
});
