// Market scanner: scans top USDT pairs for breakout, pullback, trend, oversold,
// volume, OI, funding, new-listing, liquidity and relative-strength signals.
import { createServerFn } from "@tanstack/react-start";

export type ScanHit = { symbol: string; price: number; change: number; detail: string; value: number };
export type ScanCategory = { id: string; title: string; blurb: string; hits: ScanHit[] };
export type ScannerResult = { categories: ScanCategory[]; scannedAt: number; source: string };

const STABLES = new Set(["USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "BUSD", "USD1", "XUSD", "USDE", "AEUR", "EURI", "PAXG", "WBTC", "BFUSD", "RLUSD", "USDG"]);
const BINANCE_HOSTS = ["https://data-api.binance.vision", "https://api.binance.com"];

type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

async function getJson<T>(url: string): Promise<T | null> {
  try {
    const r = await fetch(url);
    if (!r.ok) return null;
    return (await r.json()) as T;
  } catch {
    return null;
  }
}

async function klines(symbol: string, interval: string, limit: number): Promise<Candle[]> {
  for (const host of BINANCE_HOSTS) {
    const data = await getJson<(string | number)[][]>(`${host}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
    if (Array.isArray(data) && data.length) {
      return data.map((k) => ({ time: Number(k[0]!) / 1000, open: +k[1]!, high: +k[2]!, low: +k[3]!, close: +k[4]!, volume: +k[5]! }));
    }
  }
  // OKX fallback
  const bar = interval === "1d" ? "1D" : "4H";
  const okx = await getJson<{ data?: string[][] }>(`https://www.okx.com/api/v5/market/candles?instId=${symbol.replace(/USDT$/, "-USDT")}&bar=${bar}&limit=${limit}`);
  if (okx?.data?.length) {
    return okx.data.map((k) => ({ time: Number(k[0]!) / 1000, open: +k[1]!, high: +k[2]!, low: +k[3]!, close: +k[4]!, volume: +k[5]! })).reverse();
  }
  return [];
}

function rsi14(closes: number[]): number | null {
  if (closes.length < 15) return null;
  let gain = 0, loss = 0;
  for (let i = 1; i <= 14; i++) {
    const d = closes[i]! - closes[i - 1]!;
    if (d > 0) gain += d; else loss -= d;
  }
  let avgG = gain / 14, avgL = loss / 14;
  for (let i = 15; i < closes.length; i++) {
    const d = closes[i]! - closes[i - 1]!;
    avgG = (avgG * 13 + Math.max(d, 0)) / 14;
    avgL = (avgL * 13 + Math.max(-d, 0)) / 14;
  }
  if (avgL === 0) return 100;
  return 100 - 100 / (1 + avgG / avgL);
}

const pct = (n: number, d = 1) => `${n >= 0 ? "+" : ""}${n.toFixed(d)}%`;

async function scan(): Promise<ScannerResult> {
  const tickers = await getJson<{ symbol: string; lastPrice: string; priceChangePercent: string; quoteVolume: string }[]>(
    `${BINANCE_HOSTS[0]}/api/v3/ticker/24hr`,
  );
  let usdt = (Array.isArray(tickers) ? tickers : [])
    .filter((t) => t.symbol.endsWith("USDT") && !STABLES.has(t.symbol.replace(/USDT$/, "")))
    .map((t) => ({ symbol: t.symbol, base: t.symbol.replace(/USDT$/, ""), price: Number(t.lastPrice), change: Number(t.priceChangePercent), volume: Number(t.quoteVolume) }))
    .filter((t) => t.volume > 3_000_000)
    .sort((a, b) => b.volume - a.volume)
    .slice(0, 60);

  if (!usdt.length) {
    const okx = await getJson<{ data?: { instId: string; last: string; open24h: string; volCcy24h: string }[] }>("https://www.okx.com/api/v5/market/tickers?instType=SPOT");
    usdt = (okx?.data ?? []).filter(t => t.instId.endsWith("-USDT") && !STABLES.has(t.instId.replace(/-USDT$/, "")))
      .map(t => ({ symbol: t.instId.replace("-", ""), base: t.instId.replace(/-USDT$/, ""), price: Number(t.last), change: Number(t.open24h) > 0 ? (Number(t.last) / Number(t.open24h) - 1) * 100 : 0, volume: Number(t.volCcy24h) }))
      .filter(t => t.volume > 3_000_000 && Number.isFinite(t.price)).sort((a, b) => b.volume - a.volume).slice(0, 60);
  }

  // Daily candles for each candidate, in parallel batches.
  const dailyMap = new Map<string, Candle[]>();
  for (let i = 0; i < usdt.length; i += 10) {
    const batch = usdt.slice(i, i + 10);
    const results = await Promise.all(batch.map((t) => klines(t.symbol, "1d", 200).catch(() => [] as Candle[])));
    batch.forEach((t, j) => dailyMap.set(t.symbol, results[j] ?? []));
  }

  const btc = dailyMap.get("BTCUSDT") ?? [];
  const btcChange30 = btc.length > 31 ? (btc[btc.length - 1]!.close / btc[btc.length - 31]!.close - 1) * 100 : 0;

  const breakout: ScanHit[] = [];
  const pullback: ScanHit[] = [];
  const trend: ScanHit[] = [];
  const oversold: ScanHit[] = [];
  const volumeSurge: ScanHit[] = [];
  const newListings: ScanHit[] = [];
  const liquidity: ScanHit[] = [];
  const relStrength: ScanHit[] = [];

  for (const t of usdt) {
    const d = dailyMap.get(t.symbol) ?? [];
    if (d.length < 30) {
      if (d.length >= 5) newListings.push({ symbol: t.base, price: t.price, change: t.change, value: d.length, detail: `Listed ~${d.length} days ago · ${pct(t.change)} today` });
      continue;
    }
    const closes = d.map((c) => c.close);
    const last = closes[closes.length - 1]!;
    const lookback = d.slice(-60, -1); // exclude today
    const high60 = Math.max(...lookback.map((c) => c.high));
    const low20 = Math.min(...d.slice(-20).map((c) => c.low));
    const r = rsi14(closes);
    const chg30 = (last / closes[closes.length - 31]!! - 1) * 100;

    // Breakout watch: within 3% of the 60-day high.
    const distHigh = (high60 - last) / last * 100;
    if (distHigh >= 0 && distHigh <= 3) breakout.push({ symbol: t.base, price: t.price, change: t.change, value: distHigh, detail: `${distHigh.toFixed(1)}% below 60-day high $${high60.toLocaleString("en-US", { maximumFractionDigits: high60 < 1 ? 4 : 0 })}` });

    // Pullback: uptrend (price > 50d avg) but 5%+ off the 30d high and near 20d low.
    const ma50 = closes.slice(-50).reduce((a, b) => a + b, 0) / Math.min(50, closes.length);
    const offHigh = (high60 - last) / high60 * 100;
    const nearLow = (last - low20) / low20 * 100;
    if (last > ma50 && offHigh >= 5 && nearLow <= 4) pullback.push({ symbol: t.base, price: t.price, change: t.change, value: offHigh, detail: `${offHigh.toFixed(1)}% off recent high, sitting near 20-day support` });

    // Trend strength: 30d gain + price above 50d average.
    if (chg30 > 10 && last > ma50) trend.push({ symbol: t.base, price: t.price, change: t.change, value: chg30, detail: `${pct(chg30)} over 30 days, above its 50-day average` });

    // Oversold: RSI < 32 or big weekly drop.
    const chg7 = closes.length > 8 ? (last / closes[closes.length - 8]!! - 1) * 100 : 0;
    if ((r !== null && r < 32) || chg7 < -15) oversold.push({ symbol: t.base, price: t.price, change: t.change, value: r ?? chg7, detail: r !== null && r < 32 ? `RSI ${r.toFixed(0)} — heavily sold` : `${pct(chg7)} this week` });

    // Volume surge: today's volume vs 20d average (from klines, in base units).
    const vols = d.slice(-21, -1).map((c) => c.volume);
    const avgVol = vols.reduce((a, b) => a + b, 0) / vols.length;
    const todayVol = d[d.length - 1]!.volume;
    const volRatio = avgVol > 0 ? todayVol / avgVol : 0;
    if (volRatio >= 2) volumeSurge.push({ symbol: t.base, price: t.price, change: t.change, value: volRatio, detail: `${volRatio.toFixed(1)}× its 20-day average volume` });

    // Liquidity watch: 24h quote volume at least 2× the 7d daily average turnover.
    const week = d.slice(-8, -1);
    const turnover = week.map((c) => c.volume * c.close);
    const avgTurn = turnover.reduce((a, b) => a + b, 0) / turnover.length;
    const liqRatio = avgTurn > 0 ? t.volume / avgTurn : 0;
    if (liqRatio >= 2 && t.volume > 20_000_000) liquidity.push({ symbol: t.base, price: t.price, change: t.change, value: liqRatio, detail: `Trading ${liqRatio.toFixed(1)}× its usual daily turnover` });

    // Relative strength vs BTC.
    const rs = chg30 - btcChange30;
    if (rs > 8 && t.symbol !== "BTCUSDT") relStrength.push({ symbol: t.base, price: t.price, change: t.change, value: rs, detail: `${pct(rs)} vs Bitcoin over 30 days` });
  }

  // Derivatives: funding extremes + open interest changes (OKX).
  const funding: ScanHit[] = [];
  const oiChanges: ScanHit[] = [];
  const [fundingData, oiData] = await Promise.all([
    getJson<{ data?: { instId: string; fundingRate: string }[] }>("https://www.okx.com/api/v5/public/funding-rate?instType=SWAP"),
    getJson<{ data?: { instId: string; oiCcy: string; oiUsd: string }[] }>("https://www.okx.com/api/v5/public/open-interest?instType=SWAP"),
  ]);
  const oiMap = new Map((oiData?.data ?? []).map((o) => [o.instId, Number(o.oiUsd)]));
  for (const f of fundingData?.data ?? []) {
    if (!f.instId.endsWith("-USDT-SWAP")) continue;
    const base = f.instId.replace(/-USDT-SWAP$/, "");
    const rate = Number(f.fundingRate) * 100;
    if (Math.abs(rate) >= 0.05) {
      const t = usdt.find((x) => x.base === base);
      funding.push({ symbol: base, price: t?.price ?? 0, change: t?.change ?? 0, value: rate, detail: `Funding ${pct(rate, 3)} — ${rate > 0 ? "crowded longs" : "crowded shorts"}` });
    }
  }
  // OI change: compare current OI with 24h-ago from the rubik series for the top coins.
  const oiCandidates = usdt.slice(0, 25);
  const oiResults = await Promise.all(
    oiCandidates.map((t) =>
      getJson<{ data?: [string, string, string][] }>(`https://www.okx.com/api/v5/rubik/stat/contracts/open-interest-volume?ccy=${t.base}&period=1D`),
    ),
  );
  oiCandidates.forEach((t, i) => {
    const rows = oiResults[i]?.data ?? [];
    if (rows.length >= 3 && rows[0] && rows[1]) {
      const latest = Number(rows[0][1]);
      const prev = Number(rows[1][1]);
      if (prev > 0) {
        const chg = (latest / prev - 1) * 100;
        if (Math.abs(chg) >= 10) oiChanges.push({ symbol: t.base, price: t.price, change: t.change, value: chg, detail: `Open interest ${pct(chg)} in 24h (OKX)` });
      }
    }
  });

  const byValue = (a: ScanHit, b: ScanHit) => Math.abs(b.value) - Math.abs(a.value);
  const categories: ScanCategory[] = [
    { id: "breakout", title: "Breakout Watch", blurb: "Coins closing in on their 60-day high — a break above it often attracts new buyers.", hits: breakout.sort((a, b) => a.value - b.value).slice(0, 6) },
    { id: "pullback", title: "Pullback Opportunities", blurb: "Coins in an uptrend that have dipped back towards recent support.", hits: pullback.sort((a, b) => b.value - a.value).slice(0, 6) },
    { id: "trend", title: "Trend Strength", blurb: "Coins with strong, established upward trends over the past month.", hits: trend.sort(byValue).slice(0, 6) },
    { id: "oversold", title: "Oversold Watch", blurb: "Coins under heavy selling pressure — sometimes near exhaustion, sometimes falling knives.", hits: oversold.sort((a, b) => a.value - b.value).slice(0, 6) },
    { id: "volume", title: "Volume Surge", blurb: "Unusual trading activity — something is happening with these coins.", hits: volumeSurge.sort(byValue).slice(0, 6) },
    { id: "oi", title: "Open Interest Changes", blurb: "Big shifts in derivatives positioning — new money piling in or rushing out.", hits: oiChanges.sort(byValue).slice(0, 6) },
    { id: "funding", title: "Funding Rate Extremes", blurb: "Crowded bets in futures markets — extreme positioning often precedes a squeeze.", hits: funding.sort(byValue).slice(0, 6) },
    { id: "new", title: "New Listings", blurb: "Recently listed coins and their early trading. Higher risk, less history.", hits: newListings.sort((a, b) => a.value - b.value).slice(0, 6) },
    { id: "liquidity", title: "Liquidity Watch", blurb: "Coins trading far more than usual — money is flowing in or out fast.", hits: liquidity.sort(byValue).slice(0, 6) },
    { id: "strength", title: "Relative Strength", blurb: "Coins beating Bitcoin over the past month — where the momentum money is.", hits: relStrength.sort(byValue).slice(0, 6) },
  ];

  return { categories, scannedAt: Date.now(), source: "Binance + OKX" };
}

let cache: { at: number; data: ScannerResult } | null = null;

export async function scanMarket(): Promise<ScannerResult> {
  if (cache && Date.now() - cache.at < 3 * 60_000) return cache.data;
  try {
    const data = await scan();
    if (data.categories.some((c) => c.hits.length)) {
      cache = { at: Date.now(), data };
      return data;
    }
  } catch {
    // fall through to cache
  }
  if (cache) return cache.data;
  return { categories: [], scannedAt: Date.now(), source: "unavailable" };
}

export const getScanner = createServerFn({ method: "GET" }).handler(() => scanMarket());
