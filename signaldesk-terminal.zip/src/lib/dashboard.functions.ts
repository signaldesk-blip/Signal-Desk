import { createServerFn } from "@tanstack/react-start";
import { getMacro } from "./macro.server";

export type CalEvent = { title: string; country: string; date: string; impact: string; forecast: string; previous: string; actual: string };
export type Mover = { symbol: string; price: number; change: number; volume: number };
export type News = { title: string; link: string; date: string; source: string };
export type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

// Per-isolate cache: respects source rate limits and keeps the last good value if a source fails.
const cache = new Map<string, { at: number; value: unknown }>();

async function json<T>(url: string, ttlMs = 30_000): Promise<T | null> {
  const hit = cache.get(url);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  try {
    const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 SignalDesk" } });
    if (!r.ok) return (hit?.value as T) ?? null;
    const value = (await r.json()) as T;
    cache.set(url, { at: Date.now(), value });
    return value;
  } catch {
    return (hit?.value as T) ?? null;
  }
}

async function rss(url: string, source: string): Promise<News[]> {
  try {
    const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 SignalDesk" } });
    if (!r.ok) return [];
    const xml = await r.text();
    const strip = (s = "") => s.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&#039;|&#39;/g, "'").replace(/&quot;/g, '"').trim();
    return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0, 12).map((m) => {
      const it = m[1] ?? "";
      const get = (t: string) => strip(it.match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`))?.[1]);
      return { title: get("title"), link: get("link"), date: get("pubDate"), source };
    });
  } catch {
    return [];
  }
}

const STABLES = new Set(["USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "BUSD", "USD1", "XUSD", "USDE", "AEUR", "EURI", "PAXG", "WBTC", "BFUSD", "RLUSD"]);

export const getDashboard = createServerFn({ method: "GET" }).handler(async () => {
  const [calendar, fng, global, tickers, ct, decrypt, macro] = await Promise.all([
    json<Omit<CalEvent, "actual">[]>("https://nfs.faireconomy.media/ff_calendar_thisweek.json", 30 * 60_000),
    json<{ data: { value: string; value_classification: string }[] }>("https://api.alternative.me/fng/?limit=8", 30 * 60_000),
    json<{ data: { total_market_cap: { usd: number }; total_volume: { usd: number }; market_cap_percentage: Record<string, number>; market_cap_change_percentage_24h_usd: number } }>("https://api.coingecko.com/api/v3/global", 3 * 60_000),
    json<{ symbol: string; lastPrice: string; priceChangePercent: string; quoteVolume: string }[]>("https://data-api.binance.vision/api/v3/ticker/24hr"),
    rss("https://cointelegraph.com/rss", "Cointelegraph"),
    rss("https://decrypt.co/feed", "Decrypt"),
    getMacro().catch(() => []),
  ]);

  let usdt: Mover[] = (Array.isArray(tickers) ? tickers : [])
    .filter((t) => t.symbol.endsWith("USDT") && !STABLES.has(t.symbol.replace(/USDT$/, "")) && Number(t.quoteVolume) > 5_000_000)
    .map((t) => ({ symbol: t.symbol.replace(/USDT$/, ""), price: Number(t.lastPrice), change: Number(t.priceChangePercent), volume: Number(t.quoteVolume) }));

  // Binance blocks some server regions (incl. the published host) — fall back to OKX spot tickers.
  if (usdt.length === 0) {
    const okx = await json<{ data?: { instId: string; last: string; open24h: string; volCcy24h: string }[] }>(
      "https://www.okx.com/api/v5/market/tickers?instType=SPOT",
    );
    usdt = (okx?.data ?? [])
      .filter((t) => t.instId.endsWith("-USDT") && !STABLES.has(t.instId.replace(/-USDT$/, "")) && Number(t.volCcy24h) > 1_000_000)
      .map((t) => {
        const last = Number(t.last);
        const open = Number(t.open24h);
        return { symbol: t.instId.replace(/-USDT$/, ""), price: last, change: open ? ((last - open) / open) * 100 : 0, volume: Number(t.volCcy24h) };
      });
  }
  const sorted = [...usdt].sort((a, b) => b.change - a.change);
  const majors = ["BTC", "ETH", "SOL", "XRP", "BNB", "DOGE", "ADA", "LINK", "AVAX", "SUI"]
    .map((s) => usdt.find((m) => m.symbol === s))
    .filter((m): m is Mover => !!m);

  const news = [...ct, ...decrypt]
    .filter((n) => n.title)
    .sort((a, b) => Date.parse(b.date) - Date.parse(a.date))
    .slice(0, 14);

  return {
    calendar: (calendar ?? []).map((e) => ({ ...e, actual: "" })),
    fearGreed: (fng?.data ?? []).map((d) => ({ value: Number(d.value), label: d.value_classification })),
    global: global
      ? {
          marketCap: global.data.total_market_cap.usd,
          volume: global.data.total_volume.usd,
          btcDom: global.data.market_cap_percentage["btc"] ?? 0,
          ethDom: global.data.market_cap_percentage["eth"] ?? 0,
          change24h: global.data.market_cap_change_percentage_24h_usd,
        }
      : null,
    gainers: sorted.slice(0, 8),
    losers: sorted.slice(-8).reverse(),
    volumeLeaders: [...usdt].sort((a, b) => b.volume - a.volume).slice(0, 8),
    majors,
    news,
    macro,
    updatedAt: new Date().toISOString(),
  };
});
