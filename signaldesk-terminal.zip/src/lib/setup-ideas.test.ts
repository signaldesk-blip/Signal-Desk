import { describe, expect, it } from "vitest";
import { setupRequest, calculateSetup } from "./setup-ideas";

describe("Setup idea choices", () => {
  it("requests short-term shorts using only available 4-hour data", () => {
    const request = setupRequest("SOL", "ltf-short", false);
    expect(request).toContain("Direction must be short");
    expect(request).toContain("Use 4-hour candles for short-term entries");
    expect(request).toContain("Do not claim 15-minute or 1-hour analysis");
  });
  it("requests swing longs from higher-timeframe structure", () => {
    const request = setupRequest("SOL", "htf-long", false);
    expect(request).toContain("Direction must be long");
    expect(request).toContain("Use daily/weekly structure for swing entries, stops and targets");
  });
  it("computes displayed ratio rather than trusting generated arithmetic", () => {
    const idea = calculateSetup(
      {
        asset: "SOL",
        direction: "long",
        timeframe: "Daily swing",
        entry: 100,
        stop: 92,
        target: 160,
        explanation: "Historical reaction",
        confirmation: "Wait",
        opposingEvidence: "Weak trend",
        invalidation: "Breakdown",
        expiresAt: "2026-10-13",
      },
      "2026-10-12",
    );
    expect(idea.rewardToRisk).toBe(7.5);
  });
});
