import { tool } from "ai";
import { z } from "zod";
import { getMarket } from "../market.server";
import { getLiquidations } from "../liquidations.server";
import { getOpenInterest } from "../open-interest.server";
import { getMacro } from "../macro.server";
import { setupIdeaSchema, calculateSetup } from "../setup-ideas";

function ticker(input: string) {
  const symbol = input.trim().toUpperCase();
  if (!/^[A-Z0-9]{1,12}$/.test(symbol)) throw new Error("Use a ticker such as BTC, ETH or SOL.");
  return symbol;
}

export async function marketSnapshot(asset: string) {
  const symbol = ticker(asset);
  const [market, liquidations, oi] = await Promise.all([
    getMarket(symbol).catch(() => null),
    getLiquidations(symbol),
    getOpenInterest(symbol),
  ]);
  if (!market || !Number.isFinite(market.stats.price) || market.stats.price <= 0) {
    return {
      asset: symbol,
      retrievedAt: new Date().toISOString(),
      available: false,
      error: "No current candle data available. Do not invent prices, chart levels or setups.",
    };
  }
  const timeframes = Object.entries(market.candles).map(([timeframe, candles]) => {
    const latest = candles.at(-1);
    const recent = candles.slice(-30);
    return {
      timeframe,
      latestCandleOpenAt: latest ? new Date(latest.time * 1000).toISOString() : null,
      note: "Last candle may still be forming. Times are candle opens, not closes.",
      recentRange: {
        low: Math.min(...recent.map((c) => c.low)),
        high: Math.max(...recent.map((c) => c.high)),
      },
      candles: recent.map((c) => ({ ...c, timestamp: new Date(c.time * 1000).toISOString() })),
    };
  });
  return {
    asset: symbol,
    available: true,
    retrievedAt: new Date().toISOString(),
    sources:
      "Spot candles: Binance with OKX fallback; derivatives: OKX only. Price is latest 4h candle close, not a separate tick quote.",
    stats: market.stats,
    timeframes,
    openInterest: oi
      ? {
          latestUsd: oi.latestUsd,
          change24hPct: oi.change24hPct,
          change7dPct: oi.change7dPct,
          observedAt: oi["1h"].at(-1)?.time
            ? new Date((oi["1h"].at(-1)?.time ?? 0) * 1000).toISOString()
            : null,
        }
      : null,
    liquidations: liquidations
      ? {
          ...liquidations,
          caveat:
            "Recent executed liquidations from one exchange, not future liquidation heatmaps. Cached data may be older; window start is sinceMs.",
        }
      : null,
    caveats:
      "Open interest alone cannot identify new longs versus shorts; every contract has both. Volume is base-asset candle volume. Correlation is approximate daily returns. Missing data is unavailable, not zero.",
  };
}

export function createCopilotTools() {
  const checked = new Map<string, Awaited<ReturnType<typeof marketSnapshot>>>();
  return {
    marketData: tool({
      description:
        "Check timestamped weekly, daily and 4-hour candles, RSI, volume, funding, open interest and executed liquidations for an asset. Must use before current technical claims or setup ideas; use separately for each compared asset.",
      inputSchema: z.object({ asset: z.string() }),
      execute: async ({ asset }) => {
        const result = await marketSnapshot(asset);
        checked.set(result.asset, result);
        return result;
      },
    }),
    macroData: tool({
      description:
        "Read real US macro releases from FRED. Observation dates differ from retrieval dates; do not call historical releases today's news.",
      inputSchema: z.object({}),
      execute: async () => ({
        retrievedAt: new Date().toISOString(),
        source: "FRED, United States",
        figures: await getMacro().catch(() => []),
      }),
    }),
    setupCandidates: tool({
      description:
        "Get scanner watchlist candidates, not recommendations. Must then check marketData for each chosen asset. Empty result means no candidates available.",
      inputSchema: z.object({}),
      execute: async () => {
        const { scanMarket } = await import("../scanner.server");
        const result = await scanMarket();
        return {
          scannedAt: new Date(result.scannedAt).toISOString(),
          source: result.source,
          candidates: result.categories
            .filter((c) => ["breakout", "pullback", "trend"].includes(c.id))
            .map((c) => ({ category: c.title, hits: c.hits.slice(0, 3) })),
        };
      },
    }),
    presentSetup: tool({
      description:
        "Present a compact conditional setup card after marketData has checked this asset during this request. Numeric reward/risk is calculated by the app. Use only for coherent, evidence-grounded ideas. Keep each explanatory field to one short plain-English sentence.",
      inputSchema: setupIdeaSchema,
      execute: async (input) => {
        const symbol = ticker(input.asset);
        const snapshot = checked.get(symbol);
        if (!snapshot?.available)
          throw new Error("Check current market data first; no setup can be shown without it.");
        return calculateSetup({ ...input, asset: symbol }, snapshot.retrievedAt);
      },
    }),
  };
}
