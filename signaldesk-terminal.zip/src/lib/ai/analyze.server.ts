import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output } from "ai";
import { z } from "zod";

import { getMarket, summarizeForAI } from "../market.server";
import { getLiquidations, liqSummary } from "../liquidations.server";
import { getOpenInterest, oiSummary } from "../open-interest.server";
import { createLovableAiGatewayRunIdFetch, getLovableAiGatewayRunId } from "./run-id.ts";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
const MODEL = "openai/gpt-6-astra";

const signal = z.object({
  name: z.string(),
  reading: z.string().describe("Max 6 words"),
  sentiment: z.enum(["bullish", "bearish", "neutral"]),
});

export const analysisSchema = z.object({
  bias: z.enum(["bullish", "bearish", "neutral"]),
  confidence: z.number().describe("0-100"),
  headline: z.string().describe("One sentence, max 14 words"),
  zones: z
    .array(
      z.object({
        type: z.enum(["demand", "supply"]),
        low: z.number(),
        high: z.number(),
        timeframe: z.enum(["1w", "1d", "4h"]),
        label: z.string().describe("Max 4 words"),
      }),
    )
    .describe("2-3 supply/demand zones PER timeframe (1w, 1d and 4h each), each derived from that timeframe's candles; weekly zones wider, 4h zones tight"),
  levels: z
    .array(z.object({ price: z.number(), type: z.enum(["support", "resistance"]), label: z.string(), timeframe: z.enum(["1w", "1d", "4h"]) }))
    .describe("2-3 key horizontal levels PER timeframe (1w, 1d and 4h each), from that timeframe's swing highs/lows"),
  signals: z.array(signal).describe("Exactly: Weekly trend, Daily structure, 4H action, Volume, RSI, Open interest, Funding, Liquidations, BTC correlation, Macro"),
  bull: z.object({ trigger: z.number(), target: z.number(), points: z.array(z.string()).describe("2-3 short points") }),
  bear: z.object({ trigger: z.number(), target: z.number(), points: z.array(z.string()).describe("2-3 short points") }),
  why: z.array(z.string()).describe("3-4 short bullets explaining the conclusion"),
});

export type Analysis = z.infer<typeof analysisSchema>;

const SYSTEM = `You are a senior crypto technical analyst. You receive LIVE candle data and derivatives stats.
Analyze weekly trend/structure, daily support/resistance and supply/demand, 4H price action, volume, RSI (momentum, divergences), real open interest trend (rising OI + rising price = new longs; rising OI + falling price = new shorts; falling OI = positions closing), funding rate one-sidedness, real liquidation clusters, BTC correlation and the macro backdrop.
All prices MUST be grounded in the provided candles. Zones must be tight, realistic price ranges near where price has reacted. Keep all text extremely short — this is shown on charts and cards, not prose. Not financial advice.`;

function jsonError(status: number, message: string) {
  return Response.json({ error: message }, { status });
}

export async function handleAnalyze(request: Request): Promise<Response> {
  let body: { coin?: unknown };
  try {
    body = await request.json();
  } catch {
    return jsonError(400, "Invalid request body.");
  }
  const ticker = typeof body.coin === "string" ? body.coin.trim().toUpperCase().replace(/[^A-Z0-9]/g, "") : "";
  if (!ticker || ticker.length > 12) return jsonError(400, "Please enter a ticker like BTC or ETH.");

  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return jsonError(500, "AI is not configured for this app yet.");

  let market;
  try {
    market = await getMarket(ticker);
  } catch {
    return jsonError(404, `No market data found for ${ticker}. Try a ticker listed on Binance (e.g. DOT, NEAR, PEPE).`);
  }
  const [liq, oi] = await Promise.all([getLiquidations(ticker).catch(() => null), getOpenInterest(ticker).catch(() => null)]);

  try {
    const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
    const provider = createOpenAI({
      baseURL: GATEWAY_URL,
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
      fetch: runIdFetch.fetch,
    });
    const result = streamText({
      model: provider.responses(MODEL),
      system: SYSTEM,
      prompt: `${summarizeForAI(market)}\n${liqSummary(liq)}\n${oiSummary(oi)}`,
      output: Output.object({ schema: analysisSchema }),
      abortSignal: request.signal,
      providerOptions: {
        openai: { forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", store: false, include: ["reasoning.encrypted_content"] },
      },
    });
    return Response.json({ market, analysis: await result.output, liquidations: liq?.clusters ?? [], openInterest: oi ? { "1h": oi["1h"], "1d": oi["1d"], latestUsd: oi.latestUsd, change24hPct: oi.change24hPct, change7dPct: oi.change7dPct } : null });
  } catch (error) {
    const status =
      typeof error === "object" && error !== null && "statusCode" in error
        ? Number((error as { statusCode?: unknown }).statusCode)
        : 0;
    if (status === 402) return jsonError(402, "AI credits are exhausted. Add credits in workspace billing to continue.");
    if (status === 429) return jsonError(429, "The AI service is busy. Please try again in a moment.");
    return jsonError(500, "The analysis could not be completed. Please try again.");
  }
}
