import { useCallback, useEffect, useState } from "react";

const KEY = "signaldesk-view-mode";

/** Simple (beginner-friendly) vs Advanced chart view, remembered per browser. */
export function useViewMode() {
  const [advanced, setAdvanced] = useState(false);
  useEffect(() => {
    try { setAdvanced(window.localStorage.getItem(KEY) === "advanced"); } catch { /* keep default */ }
  }, []);
  const choose = useCallback((next: boolean) => {
    setAdvanced(next);
    try { window.localStorage.setItem(KEY, next ? "advanced" : "simple"); } catch { /* ignore */ }
  }, []);
  return { advanced, choose };
}
