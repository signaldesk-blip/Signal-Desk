// Real liquidations from OKX public perpetual-swap feed, grouped into price clusters.
export type LiqCluster = { price: number; side: "longs" | "shorts"; usd: number; count: number };
export type LiqData = { clusters: LiqCluster[]; longsUsd: number; shortsUsd: number; sinceMs: number | null; source: string };

const cache = new Map<string, { at: number; value: LiqData }>();
const ctValCache = new Map<string, number>();

type Detail = { bkPx: string; sz: string; posSide: string; side: string; ts: string };

async function ctVal(instId: string): Promise<number> {
  const hit = ctValCache.get(instId);
  if (hit) return hit;
  const r = await fetch(`https://www.okx.com/api/v5/public/instruments?instType=SWAP&instId=${instId}`);
  const j = (await r.json()) as { data?: { ctVal: string }[] };
  const v = Number(j.data?.[0]?.ctVal ?? NaN);
  if (!Number.isFinite(v)) throw new Error("no instrument");
  ctValCache.set(instId, v);
  return v;
}

export async function getLiquidations(ticker: string): Promise<LiqData | null> {
  const hit = cache.get(ticker);
  if (hit && Date.now() - hit.at < 60_000) return hit.value;
  try {
    const uly = `${ticker}-USDT`;
    const cv = await ctVal(`${uly}-SWAP`);
    const details: Detail[] = [];
    let after = "";
    for (let page = 0; page < 3; page++) {
      const r = await fetch(`https://www.okx.com/api/v5/public/liquidation-orders?instType=SWAP&uly=${uly}&state=filled&limit=100${after ? `&after=${after}` : ""}`);
      if (!r.ok) break;
      const j = (await r.json()) as { data?: { details?: Detail[] }[] };
      const d = j.data?.[0]?.details ?? [];
      if (!d.length) break;
      details.push(...d);
      after = d[d.length - 1]!.ts;
      if (d.length < 100) break;
    }
    if (!details.length) return hit?.value ?? null;

    const prices = details.map((d) => Number(d.bkPx));
    const mid = prices.reduce((a, b) => a + b, 0) / prices.length;
    const step = mid * 0.004; // ~0.4% buckets
    const buckets = new Map<string, LiqCluster & { pxSum: number }>();
    let longsUsd = 0, shortsUsd = 0;
    for (const d of details) {
      const px = Number(d.bkPx);
      const usd = Number(d.sz) * cv * px;
      const side = d.posSide === "short" || (d.posSide === "net" && d.side === "buy") ? "shorts" : "longs";
      if (side === "longs") longsUsd += usd; else shortsUsd += usd;
      const key = `${side}:${Math.round(px / step)}`;
      const b = buckets.get(key) ?? { price: 0, side, usd: 0, count: 0, pxSum: 0 };
      b.usd += usd; b.count += 1; b.pxSum += px * usd;
      buckets.set(key, b);
    }
    const clusters = [...buckets.values()]
      .map(({ pxSum, ...b }) => ({ ...b, price: Number((pxSum / b.usd).toPrecision(6)) }))
      .sort((a, b) => b.usd - a.usd)
      .slice(0, 3);
    const value: LiqData = {
      clusters, longsUsd, shortsUsd,
      sinceMs: Math.min(...details.map((d) => Number(d.ts))),
      source: "OKX perpetuals",
    };
    cache.set(ticker, { at: Date.now(), value });
    return value;
  } catch {
    return hit?.value ?? null;
  }
}

export function liqSummary(l: LiqData | null): string {
  if (!l) return "Liquidations: no live data available — do not invent figures.";
  const m = (n: number) => `$${(n / 1e6).toFixed(2)}M`;
  return `REAL recent liquidations (${l.source}, since ${new Date(l.sinceMs ?? 0).toISOString()}): longs ${m(l.longsUsd)}, shorts ${m(l.shortsUsd)}. Largest clusters: ${l.clusters.map((c) => `${c.side} ${m(c.usd)} @ ${c.price}`).join("; ")}`;
}
