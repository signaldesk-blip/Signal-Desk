import { useCallback, useEffect, useState } from "react";

const KEY = "signaldesk-chart-surface";

/** Chart background choice (white or black canvas), remembered per browser. */
export function useChartSurface() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    try {
      setDark(window.localStorage.getItem(KEY) === "dark");
    } catch {
      /* storage unavailable — keep the light default */
    }
  }, []);

  const choose = useCallback((next: boolean) => {
    setDark(next);
    try {
      window.localStorage.setItem(KEY, next ? "dark" : "light");
    } catch {
      /* storage unavailable — the choice still applies for this visit */
    }
  }, []);

  return { dark, choose };
}
