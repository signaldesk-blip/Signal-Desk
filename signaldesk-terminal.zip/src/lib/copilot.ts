import { z } from "zod";

export const tradeChallengeSchema = z
  .object({
    asset: z
      .string()
      .trim()
      .min(1)
      .max(12)
      .regex(/^[A-Za-z0-9]+$/),
    direction: z.enum(["long", "short"]),
    entry: z.number().positive().finite(),
    stop: z.number().positive().finite(),
    target: z.number().positive().finite(),
    reasoning: z.string().trim().min(1).max(4000),
  })
  .superRefine((t, ctx) => {
    const valid =
      t.direction === "long"
        ? t.stop < t.entry && t.target > t.entry
        : t.stop > t.entry && t.target < t.entry;
    if (!valid)
      ctx.addIssue({
        code: "custom",
        message: "For a long, stop must be below entry and target above; reverse this for a short.",
      });
  });
export type TradeChallenge = z.infer<typeof tradeChallengeSchema>;

export function tradeMath(input: TradeChallenge) {
  const t = tradeChallengeSchema.parse(input);
  const risk = Math.abs(t.entry - t.stop);
  const reward = Math.abs(t.target - t.entry);
  return {
    risk,
    reward,
    rewardToRisk: reward / risk,
    breakEvenWinRatePct: (risk / (risk + reward)) * 100,
  };
}

export function challengePrompt(input: TradeChallenge) {
  const t = tradeChallengeSchema.parse(input);
  const math = tradeMath(t);
  return `Challenge my proposed trade, not a recommendation: ${t.asset.toUpperCase()} ${t.direction}. Entry $${t.entry}, stop-loss $${t.stop}, target $${t.target}. Calculated reward-to-risk ${math.rewardToRisk.toFixed(2)}:1; theoretical break-even win rate ${math.breakEvenWinRatePct.toFixed(2)}% before fees/slippage (NOT a predicted success probability). My reasoning: ${t.reasoning}\nCheck current weekly/daily/4-hour data, entry near meaningful levels, higher-timeframe support, clear invalidation, realistic target, and contradictory evidence. Separate mathematical quality from probability; never invent a win probability.`;
}

export function copilotHead(title: string, description: string) {
  return {
    meta: [
      { title: `${title} — SignalDesk` },
      { name: "description", content: description },
      { property: "og:title", content: `${title} — SignalDesk` },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}
