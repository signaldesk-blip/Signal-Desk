export type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };

// Binance geo-blocks some server locations, so try several hosts and fall
// back to OKX candles (which we already use for perps data) if all fail.
const BINANCE_HOSTS = [
  "https://data-api.binance.vision",
  "https://api.binance.com",
  "https://api1.binance.com",
  "https://api2.binance.com",
  "https://api3.binance.com",
];

const OKX_BAR: Record<string, string> = { "1w": "1W", "1d": "1D", "4h": "4H" };

async function binanceKlines(symbol: string, interval: string, limit: number): Promise<Candle[]> {
  let lastError: unknown = new Error("no hosts");
  for (const host of BINANCE_HOSTS) {
    try {
      const res = await fetch(`${host}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
      if (!res.ok) {
        lastError = new Error(`klines ${res.status}`);
        continue;
      }
      const rows = (await res.json()) as unknown[][];
      return rows.map((r) => ({
        time: Math.floor(Number(r[0]) / 1000),
        open: Number(r[1]),
        high: Number(r[2]),
        low: Number(r[3]),
        close: Number(r[4]),
        volume: Number(r[5]),
      }));
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError;
}

async function okxKlines(symbol: string, interval: string, limit: number): Promise<Candle[]> {
  const inst = symbol.replace(/USDT$/, "-USDT");
  const bar = OKX_BAR[interval] ?? "1D";
  const res = await fetch(`https://www.okx.com/api/v5/market/candles?instId=${inst}&bar=${bar}&limit=${Math.min(limit, 300)}`);
  if (!res.ok) throw new Error(`okx candles ${res.status}`);
  const j = (await res.json()) as { data?: string[][] };
  const rows = j.data ?? [];
  if (!rows.length) throw new Error("okx candles empty");
  // OKX returns newest-first [ts, o, h, l, c, vol, ...]
  return rows
    .map((r) => ({
      time: Math.floor(Number(r[0]) / 1000),
      open: Number(r[1]),
      high: Number(r[2]),
      low: Number(r[3]),
      close: Number(r[4]),
      volume: Number(r[5]),
    }))
    .reverse();
}

async function klines(symbol: string, interval: string, limit: number): Promise<Candle[]> {
  try {
    return await binanceKlines(symbol, interval, limit);
  } catch {
    return okxKlines(symbol, interval, limit);
  }
}

export function rsi(closes: number[], period = 14): (number | null)[] {
  const out: (number | null)[] = closes.map(() => null);
  if (closes.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i]! - closes[i - 1]!;
    if (d >= 0) gain += d;
    else loss -= d;
  }
  gain /= period;
  loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i]! - closes[i - 1]!;
    gain = (gain * (period - 1) + Math.max(d, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

function correlation(a: number[], b: number[]): number | null {
  const n = Math.min(a.length, b.length);
  if (n < 5) return null;
  const ra = a.slice(-n).map((v, i, arr) => (i ? v / arr[i - 1]! - 1 : 0)).slice(1);
  const rb = b.slice(-n).map((v, i, arr) => (i ? v / arr[i - 1]! - 1 : 0)).slice(1);
  const ma = ra.reduce((s, v) => s + v, 0) / ra.length;
  const mb = rb.reduce((s, v) => s + v, 0) / rb.length;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < ra.length; i++) {
    num += (ra[i]! - ma) * (rb[i]! - mb);
    da += (ra[i]! - ma) ** 2;
    db += (rb[i]! - mb) ** 2;
  }
  return da && db ? num / Math.sqrt(da * db) : null;
}

async function okx(path: string): Promise<number | null> {
  try {
    const res = await fetch(`https://www.okx.com/api/v5/public/${path}`);
    if (!res.ok) return null;
    const j = (await res.json()) as { data?: Record<string, string>[] };
    const d = j.data?.[0];
    if (!d) return null;
    return Number(d['fundingRate'] ?? d['oiCcy'] ?? NaN);
  } catch {
    return null;
  }
}

export async function getMarket(ticker: string) {
  const symbol = `${ticker}USDT`;
  const [w, d, h4] = await Promise.all([
    klines(symbol, "1w", 104),
    klines(symbol, "1d", 200),
    klines(symbol, "4h", 200),
  ]);
  const btcDaily = ticker === "BTC" ? d : await klines("BTCUSDT", "1d", 200).catch(() => d);
  const [funding, openInterest] = await Promise.all([
    okx(`funding-rate?instId=${ticker}-USDT-SWAP`),
    okx(`open-interest?instType=SWAP&instId=${ticker}-USDT-SWAP`),
  ]);
  const closesD = d.map((c) => c.close);
  const rsiD = rsi(closesD);
  const rsi4 = rsi(h4.map((c) => c.close));
  const rsiW = rsi(w.map((c) => c.close));
  const price = h4[h4.length - 1]?.close ?? 0;
  const prev = d[d.length - 2]?.close ?? price;
  return {
    ticker,
    candles: { "1w": w, "1d": d, "4h": h4 },
    stats: {
      price,
      change24h: ((price - prev) / prev) * 100,
      rsiW: rsiW[rsiW.length - 1],
      rsiD: rsiD[rsiD.length - 1],
      rsi4h: rsi4[rsi4.length - 1],
      fundingRate: funding,
      openInterest,
      btcCorrelation30d: ticker === "BTC" ? 1 : correlation(closesD.slice(-31), btcDaily.map((c) => c.close).slice(-31)),
    },
  };
}

export type Market = Awaited<ReturnType<typeof getMarket>>;

export function summarizeForAI(m: Market): string {
  const fmt = (cs: Candle[], n: number) =>
    cs.slice(-n).map((c) => `${new Date(c.time * 1000).toISOString().slice(0, 10)} O${c.open} H${c.high} L${c.low} C${c.close} V${Math.round(c.volume)}`).join("\n");
  return `LIVE DATA for ${m.ticker}/USDT (Binance spot, OKX perps)
Stats: ${JSON.stringify(m.stats)}
Weekly candles (last 52):\n${fmt(m.candles["1w"], 52)}
Daily candles (last 90):\n${fmt(m.candles["1d"], 90)}
4H candles (last 60):\n${fmt(m.candles["4h"], 60)}`;
}
