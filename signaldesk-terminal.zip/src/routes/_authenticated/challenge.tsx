import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ShieldQuestion } from "lucide-react";
import { CopilotShell } from "@/components/Copilot/Shell";
import { copilotThreadsQuery, useCopilotThreads } from "@/components/Copilot/useThreads";
import { challengePrompt, tradeMath, tradeChallengeSchema, copilotHead } from "@/lib/copilot";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/challenge")({
  head: () =>
    copilotHead(
      "Challenge My Trade",
      "Calculate trade reward-to-risk and challenge your proposed crypto trade against timestamped market evidence.",
    ),
  loader: ({ context }) => context.queryClient.ensureQueryData(copilotThreadsQuery),
  component: ChallengePage,
  errorComponent: ({ error }) => (
    <p role="alert" className="p-8">
      {error instanceof Error ? error.message : "Could not load your trade review."}
    </p>
  ),
});

function ChallengePage() {
  const state = useCopilotThreads();
  const [asset, setAsset] = useState("SOL");
  const [direction, setDirection] = useState<"long" | "short">("long");
  const [entry, setEntry] = useState("100");
  const [stop, setStop] = useState("92");
  const [target, setTarget] = useState("160");
  const [reasoning, setReasoning] = useState("");
  const [error, setError] = useState("");
  const parsed = tradeChallengeSchema.safeParse({
    asset,
    direction,
    entry: Number(entry),
    stop: Number(stop),
    target: Number(target),
    reasoning: reasoning || "Preview mathematics",
  });
  const math = parsed.success ? tradeMath(parsed.data) : null;
  return (
    <CopilotShell
      threads={state.threads}
      onNew={() => void state.newThread()}
      onDelete={(id) => void state.deleteThread(id)}
      working={state.working}
    >
      <section className="mx-auto max-w-3xl px-6 py-10">
        <ShieldQuestion className="size-9 text-primary" />
        <h1 className="mt-4 font-display text-3xl font-semibold">Challenge my trade</h1>
        <p className="mt-3 text-muted-foreground">
          A strong ratio is only the beginning. Does the evidence support your idea?
        </p>
        <form
          className="mt-8 space-y-5"
          onSubmit={async (e) => {
            e.preventDefault();
            setError("");
            const result = tradeChallengeSchema.safeParse({
              asset,
              direction,
              entry: Number(entry),
              stop: Number(stop),
              target: Number(target),
              reasoning,
            });
            if (!result.success) {
              setError(result.error.issues[0]?.message ?? "Check your trade details.");
              return;
            }
            await state.newThread(`Challenge ${asset.toUpperCase()}`, challengePrompt(result.data));
          }}
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="space-y-2 text-sm font-medium">
              Asset
              <Input
                value={asset}
                onChange={(e) => setAsset(e.target.value)}
                required
                maxLength={12}
              />
            </label>
            <label className="space-y-2 text-sm font-medium">
              Direction
              <Select
                value={direction}
                onValueChange={(v) => setDirection(v === "short" ? "short" : "long")}
              >
                <SelectTrigger aria-label="Direction">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="long">Long — expecting a rise</SelectItem>
                  <SelectItem value="short">Short — expecting a fall</SelectItem>
                </SelectContent>
              </Select>
            </label>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              ["Entry price ($)", entry, setEntry],
              ["Stop-loss ($)", stop, setStop],
              ["Target price ($)", target, setTarget],
            ].map(([label, value, setter]) => (
              <label key={String(label)} className="space-y-2 text-sm font-medium">
                {String(label)}
                <Input
                  type="number"
                  step="any"
                  min="0.00000001"
                  value={String(value)}
                  onChange={(e) => {
                    if (typeof setter === "function") setter(e.target.value);
                  }}
                  required
                />
              </label>
            ))}
          </div>
          {math ? (
            <div className="border-y border-border py-5">
              <p className="text-sm text-muted-foreground">Proposed reward-to-risk</p>
              <p className="mt-1 text-3xl font-semibold">{math.rewardToRisk.toFixed(2)} : 1</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Risk ${math.risk.toFixed(2)} per coin · Potential reward ${math.reward.toFixed(2)}{" "}
                per coin
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                Theoretical break-even win rate: {math.breakEvenWinRatePct.toFixed(2)}% before fees
                and slippage. This is not your probability of success.
              </p>
            </div>
          ) : (
            <p className="text-sm text-destructive">
              Check that your stop and target are on the correct sides of entry.
            </p>
          )}
          <label className="block space-y-2 text-sm font-medium">
            Why are you considering this trade?
            <Textarea
              value={reasoning}
              onChange={(e) => setReasoning(e.target.value)}
              required
              maxLength={4000}
              className="min-h-28"
              placeholder="Your levels, timeframe, evidence and what would prove you wrong…"
            />
          </label>
          {(error || state.error) && (
            <p role="alert" className="text-sm text-destructive">
              {error || state.error}
            </p>
          )}
          <Button disabled={state.working || !math} type="submit">
            Review with Co-Pilot
          </Button>
          <p className="text-xs text-muted-foreground">
            Your proposal is never executed. Educational review only, not financial advice.
          </p>
        </form>
      </section>
    </CopilotShell>
  );
}
