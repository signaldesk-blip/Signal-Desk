import { createFileRoute } from "@tanstack/react-router";
import { CopilotShell, CopilotIdentity } from "@/components/Copilot/Shell";
import { copilotThreadsQuery, useCopilotThreads } from "@/components/Copilot/useThreads";
import { copilotHead } from "@/lib/copilot";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/copilot")({
  head: () =>
    copilotHead(
      "Personal Market Co-Pilot",
      "Account-saved crypto market conversations using timestamped data and independent trade reviews.",
    ),
  loader: ({ context }) => context.queryClient.ensureQueryData(copilotThreadsQuery),
  component: CopilotHome,
  errorComponent: ({ error }) => (
    <p role="alert" className="p-8">
      {error instanceof Error ? error.message : "Could not load your Co-Pilot."}
    </p>
  ),
});

function CopilotHome() {
  const state = useCopilotThreads();
  return (
    <CopilotShell
      threads={state.threads}
      onNew={() => void state.newThread()}
      onDelete={(id) => void state.deleteThread(id)}
      working={state.working}
    >
      <section className="px-6 py-12 sm:px-10">
        <CopilotIdentity />
        <h1 className="mt-6 font-display text-3xl font-semibold">Personal Market Co-Pilot</h1>
        <p className="mt-3 max-w-xl text-muted-foreground">
          Understand the evidence. Challenge your assumptions. Keep your own judgement.
        </p>
        {state.error && (
          <p role="alert" className="mt-4 text-destructive">
            {state.error}
          </p>
        )}
        <Button className="mt-7" disabled={state.working} onClick={() => void state.newThread()}>
          Start a conversation
        </Button>
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {[
            [
              "Market perspective",
              "What are the strongest arguments for and against buying Bitcoin here?",
            ],
            ["Multi-timeframe analysis", "Analyse SOL on the weekly, daily and 4-hour charts."],
            ["Compare assets", "Compare SOL, INJ and SUI based on their current market structure."],
            [
              "Keep it simple",
              "Explain Bitcoin's chart to me as if I'm completely new to trading.",
            ],
          ].map(([title, draft]) => (
            <Button
              key={title}
              variant="outline"
              className="h-auto flex-col items-start gap-2 whitespace-normal p-5 text-left"
              onClick={() => void state.newThread(title, draft)}
              disabled={state.working}
            >
              <span className="font-semibold">{title}</span>
              <span className="text-sm font-normal text-muted-foreground">{draft}</span>
            </Button>
          ))}
        </div>
      </section>
    </CopilotShell>
  );
}
