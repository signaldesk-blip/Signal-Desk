import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { CopilotShell } from "@/components/Copilot/Shell";
import { CopilotChat } from "@/components/Copilot/Chat";
import { copilotThreadsQuery, useCopilotThreads } from "@/components/Copilot/useThreads";
import { getCopilotThread } from "@/lib/copilot.functions";
import { copilotHead } from "@/lib/copilot";
import type { UIMessage } from "ai";

const threadQuery = (threadId: string) =>
  queryOptions({
    queryKey: ["copilot-thread", threadId],
    queryFn: () => getCopilotThread({ data: { threadId } }),
    staleTime: 0,
  });

export const Route = createFileRoute("/_authenticated/copilot_/$threadId")({
  head: () =>
    copilotHead(
      "Co-Pilot Conversation",
      "Your private crypto market conversation and timestamped market research.",
    ),
  validateSearch: (search: Record<string, unknown>) => ({
    draft: typeof search["draft"] === "string" ? search["draft"].slice(0, 12000) : undefined,
  }),
  loader: async ({ context, params }) => {
    await Promise.all([
      context.queryClient.ensureQueryData(copilotThreadsQuery),
      context.queryClient.fetchQuery(threadQuery(params.threadId)),
    ]);
  },
  component: ThreadPage,
  errorComponent: ({ error }) => (
    <p role="alert" className="p-8">
      {error instanceof Error ? error.message : "Could not load your conversation."}
    </p>
  ),
});

function ThreadPage() {
  const { threadId } = Route.useParams();
  const { draft } = Route.useSearch();
  const { data: thread } = useSuspenseQuery(threadQuery(threadId));
  const state = useCopilotThreads();
  return (
    <CopilotShell
      threads={state.threads}
      activeId={threadId}
      onNew={() => void state.newThread()}
      onDelete={(id) => void state.deleteThread(id)}
      working={state.working}
    >
      {state.error && (
        <p role="alert" className="p-3 text-destructive">
          {state.error}
        </p>
      )}
      <CopilotChat
        key={threadId}
        threadId={threadId}
        initialMessages={JSON.parse(thread.messagesJson) as UIMessage[]}
        draft={thread.messagesJson === "[]" ? (draft ?? "") : ""}
      />
    </CopilotShell>
  );
}
