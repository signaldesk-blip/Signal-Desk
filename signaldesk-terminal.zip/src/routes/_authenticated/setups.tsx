import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ScanLine } from "lucide-react";
import { CopilotShell } from "@/components/Copilot/Shell";
import { copilotThreadsQuery, useCopilotThreads } from "@/components/Copilot/useThreads";
import { copilotHead } from "@/lib/copilot";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { setupModes, setupRequest, type SetupMode } from "@/lib/setup-ideas";

export const Route = createFileRoute("/_authenticated/setups")({
  head: () =>
    copilotHead(
      "AI Setup Ideas",
      "Conditional educational crypto setup ideas grounded in market structure, with invalidation and opposing evidence.",
    ),
  loader: ({ context }) => context.queryClient.ensureQueryData(copilotThreadsQuery),
  component: SetupsPage,
  errorComponent: ({ error }) => (
    <p role="alert" className="p-8">
      {error instanceof Error ? error.message : "Could not load setup ideas."}
    </p>
  ),
});

function SetupsPage() {
  const state = useCopilotThreads();
  const [asset, setAsset] = useState("BTC");
  const [error, setError] = useState("");
  const [mode, setMode] = useState<SetupMode>("ltf-long");
  function requestIdeas(scan: boolean) {
    const symbol = asset.trim().toUpperCase();
    if (!scan && !/^[A-Z0-9]{1,12}$/.test(symbol)) {
      setError("Enter a ticker such as BTC or SOL.");
      return;
    }
    const draft = setupRequest(symbol, mode, scan);
    void state.newThread(
      `${scan ? "Scanner" : symbol} ${setupModes.find((item) => item.id === mode)?.label ?? "setup"}`,
      draft,
    );
  }
  return (
    <CopilotShell
      threads={state.threads}
      onNew={() => void state.newThread()}
      onDelete={(id) => void state.deleteThread(id)}
      working={state.working}
    >
      <section className="mx-auto max-w-3xl px-6 py-10">
        <ScanLine className="size-9 text-primary" />
        <h1 className="mt-4 font-display text-3xl font-semibold">AI setup ideas</h1>
        <p className="mt-3 text-muted-foreground">Conditional ideas, not instructions to trade.</p>
        <div className="mt-7 grid grid-cols-2 gap-3" role="group" aria-label="Setup type">
          {setupModes.map((choice) => (
            <Button
              key={choice.id}
              type="button"
              variant={mode === choice.id ? "default" : "outline"}
              aria-pressed={mode === choice.id}
              className="h-auto flex-col items-start gap-1 py-4"
              onClick={() => setMode(choice.id)}
            >
              <span className="font-semibold">{choice.label}</span>
              <span
                className={`text-xs font-normal ${mode === choice.id ? "text-primary-foreground" : "text-muted-foreground"}`}
              >
                {choice.detail}
              </span>
            </Button>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          LTF = lower timeframe. HTF = higher timeframe. Short-term ideas use 4-hour candles, not
          minute-by-minute data.
        </p>
        <form
          className="mt-7 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            requestIdeas(false);
          }}
        >
          <label className="block space-y-2 text-sm font-medium">
            Asset
            <Input
              value={asset}
              onChange={(e) => setAsset(e.target.value)}
              maxLength={12}
              className="max-w-xs"
            />
          </label>
          <div className="flex flex-wrap gap-3">
            <Button disabled={state.working} type="submit">
              Explore this asset
            </Button>
            <Button
              disabled={state.working}
              variant="outline"
              type="button"
              onClick={() => requestIdeas(true)}
            >
              Find scanner candidates
            </Button>
          </div>
        </form>
        {(error || state.error) && (
          <p role="alert" className="mt-4 text-destructive">
            {error || state.error}
          </p>
        )}
        <p className="mt-7 text-xs text-muted-foreground">
          Ideas are saved in a dedicated conversation. No automatic trading. Not financial advice.
        </p>
      </section>
    </CopilotShell>
  );
}
