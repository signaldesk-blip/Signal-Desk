import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Activity, BookOpen, LogOut, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { journalStats, plannedRR, resultR, resultUsd, type Direction } from "@/lib/journal";

export const Route = createFileRoute("/_authenticated/journal")({
  head: () => ({
    meta: [
      { title: "Trading Journal — SignalDesk" },
      { name: "description", content: "Log your crypto trades with entry, stop and target, and track your win rate and results." },
      { property: "og:title", content: "Trading Journal — SignalDesk" },
      { property: "og:description", content: "Log trades and track your results." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Journal,
});

type Trade = { id: string; symbol: string; direction: Direction; entry: number; stop: number; target: number; size: number | null; status: string; exit_price: number | null; notes: string | null; opened_at: string };

const fmt = (n: number) => (n >= 1000 ? n.toLocaleString("en-US", { maximumFractionDigits: 2 }) : n >= 1 ? n.toFixed(2) : n.toPrecision(4));
const num = (v: unknown) => (v == null ? null : Number(v));

function Journal() {
  const qc = useQueryClient();
  const { data: trades = [], isLoading } = useQuery({
    queryKey: ["trades"],
    queryFn: async () => {
      const { data, error } = await supabase.from("trades").select("*").order("opened_at", { ascending: false });
      if (error) throw error;
      return data.map((t) => ({ ...t, entry: Number(t.entry), stop: Number(t.stop), target: Number(t.target), size: num(t.size), exit_price: num(t.exit_price) })) as Trade[];
    },
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["trades"] });

  const [f, setF] = useState({ symbol: "BTC", direction: "long" as Direction, entry: "", stop: "", target: "", size: "", notes: "" });
  const add = useMutation({
    mutationFn: async () => {
      const entry = Number(f.entry), stop = Number(f.stop), target = Number(f.target);
      if (!(entry > 0 && stop > 0 && target > 0)) throw new Error("Enter entry, stop and target prices.");
      if (f.direction === "long" ? !(stop < entry && target > entry) : !(stop > entry && target < entry))
        throw new Error(f.direction === "long" ? "For a long, stop must be below entry and target above." : "For a short, stop must be above entry and target below.");
      const { error } = await supabase.from("trades").insert({ symbol: f.symbol.trim().toUpperCase(), direction: f.direction, entry, stop, target, size: f.size ? Number(f.size) : null, notes: f.notes || null });
      if (error) throw error;
    },
    onSuccess: () => { toast("Trade logged"); setF((x) => ({ ...x, entry: "", stop: "", target: "", size: "", notes: "" })); void refresh(); },
    onError: (e: Error) => toast(e.message),
  });

  const close = async (t: Trade, exitStr: string | null) => {
    if (exitStr == null) return;
    const exit = Number(exitStr);
    if (!(exit > 0)) { toast("Enter a valid exit price."); return; }
    const r = resultR({ ...t, exit_price: exit, status: "closed" }) ?? 0;
    const status = Math.abs(r) < 0.05 ? "breakeven" : r > 0 ? "win" : "loss";
    const { error } = await supabase.from("trades").update({ exit_price: exit, status, closed_at: new Date().toISOString() }).eq("id", t.id);
    if (error) toast(error.message); else void refresh();
  };
  const remove = async (id: string) => { const { error } = await supabase.from("trades").delete().eq("id", id); if (error) toast(error.message); else void refresh(); };

  const s = journalStats(trades);
  const input = "w-full rounded-md border border-border bg-background px-2 py-1.5 text-sm";

  return (
    <div className="min-h-screen">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground"><Activity className="size-5" /></div>
            <div><p className="font-display text-lg font-bold">SignalDesk</p><p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Trading Journal</p></div>
          </Link>
          <nav className="flex items-center gap-1 text-sm">
            <Link to="/" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Dashboard</Link>
            <Link to="/analyze" search={{ coin: undefined }} className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">AI Chart Analyst</Link>
            <button onClick={() => supabase.auth.signOut()} className="flex items-center gap-1 rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground"><LogOut className="size-4" />Sign out</button>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-4 px-4 py-6 sm:px-6">
        <section className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-5">
          <Box label="Trades" value={`${s.total}`} sub={`${s.open} open`} />
          <Box label="Win rate" value={s.winRate == null ? "–" : `${s.winRate.toFixed(0)}%`} sub={`${s.closed} closed`} />
          <Box label="Total result" value={`${s.totalR >= 0 ? "+" : ""}${s.totalR.toFixed(2)}R`} tone={s.totalR >= 0 ? "text-bull" : "text-bear"} />
          <Box label="Average per trade" value={s.avgR == null ? "–" : `${s.avgR >= 0 ? "+" : ""}${s.avgR.toFixed(2)}R`} />
          <Box label="Profit / loss" value={`${s.totalUsd >= 0 ? "+" : "-"}$${fmt(Math.abs(s.totalUsd))}`} tone={s.totalUsd >= 0 ? "text-bull" : "text-bear"} sub="trades with a size" />
        </section>

        <section className="rounded-xl border border-border bg-card">
          <h2 className="flex items-center gap-2 border-b border-border px-4 py-3 text-sm font-semibold"><BookOpen className="size-4 text-primary" />Log a trade</h2>
          <form onSubmit={(e) => { e.preventDefault(); add.mutate(); }} className="grid grid-cols-2 gap-3 p-4 text-xs text-muted-foreground sm:grid-cols-4 lg:grid-cols-7">
            <label className="space-y-1">Coin<input className={input} value={f.symbol} onChange={(e) => setF({ ...f, symbol: e.target.value })} /></label>
            <label className="space-y-1">Direction
              <select className={input} value={f.direction} onChange={(e) => setF({ ...f, direction: e.target.value as Direction })}><option value="long">Long (buy)</option><option value="short">Short (sell)</option></select>
            </label>
            <label className="space-y-1">Entry price<input inputMode="decimal" className={input} value={f.entry} onChange={(e) => setF({ ...f, entry: e.target.value })} /></label>
            <label className="space-y-1">Stop<input inputMode="decimal" className={input} value={f.stop} onChange={(e) => setF({ ...f, stop: e.target.value })} /></label>
            <label className="space-y-1">Target<input inputMode="decimal" className={input} value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })} /></label>
            <label className="space-y-1">Size (coins, optional)<input inputMode="decimal" className={input} value={f.size} onChange={(e) => setF({ ...f, size: e.target.value })} /></label>
            <div className="flex items-end"><button disabled={add.isPending} className="w-full rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60">Add trade</button></div>
            <label className="col-span-full space-y-1">Notes (optional)<input className={input} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} placeholder="Why did you take this trade?" /></label>
          </form>
        </section>

        <section className="overflow-x-auto rounded-xl border border-border bg-card">
          <table className="w-full min-w-[760px] text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-muted-foreground">
              <tr className="border-b border-border">
                {["Date", "Coin", "Side", "Entry", "Stop", "Target", "Planned R:R", "Result", ""].map((h) => <th key={h} className="px-3 py-2 text-left font-normal">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {trades.map((t) => {
                const rr = plannedRR(t), r = resultR(t), usd = resultUsd(t);
                return (
                  <tr key={t.id} className="border-b border-border/50 last:border-0" title={t.notes ?? ""}>
                    <td className="px-3 py-2 text-xs text-muted-foreground">{t.opened_at.slice(0, 10)}</td>
                    <td className="px-3 font-semibold">{t.symbol}</td>
                    <td className={`px-3 ${t.direction === "long" ? "text-bull" : "text-bear"}`}>{t.direction}</td>
                    <td className="px-3 font-mono text-xs">{fmt(t.entry)}</td>
                    <td className="px-3 font-mono text-xs text-bear">{fmt(t.stop)}</td>
                    <td className="px-3 font-mono text-xs text-bull">{fmt(t.target)}</td>
                    <td className="px-3 font-mono text-xs">{rr ? `1 : ${rr.toFixed(2)}` : "–"}</td>
                    <td className="px-3">
                      {t.status === "open" ? (
                        <button onClick={() => close(t, prompt(`Exit price for ${t.symbol}?`))} className="rounded border border-border px-2 py-0.5 text-xs hover:bg-accent">Close trade</button>
                      ) : (
                        <span className={`font-mono text-xs ${(r ?? 0) >= 0 ? "text-bull" : "text-bear"}`}>{t.status} · {r != null ? `${r >= 0 ? "+" : ""}${r.toFixed(2)}R` : ""}{usd != null ? ` · ${usd >= 0 ? "+" : "-"}$${fmt(Math.abs(usd))}` : ""}</span>
                      )}
                    </td>
                    <td className="px-3 text-right"><button aria-label="Delete trade" onClick={() => remove(t.id)} className="text-muted-foreground hover:text-bear"><Trash2 className="size-4" /></button></td>
                  </tr>
                );
              })}
              {!trades.length && <tr><td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">{isLoading ? "Loading…" : "No trades yet — log your first one above."}</td></tr>}
            </tbody>
          </table>
        </section>
        <p className="text-center text-[11px] text-muted-foreground">R = multiples of what you risked (entry to stop). Your journal is private to your account. Not financial advice.</p>
      </main>
    </div>
  );
}

function Box({ label, value, sub, tone = "" }: { label: string; value: string; sub?: string; tone?: string }) {
  return (
    <div className="bg-card px-4 py-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className={`mt-0.5 font-display text-xl font-bold ${tone}`}>{value}</p>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  );
}
