import { Fragment, useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Activity, ArrowDownRight, ArrowUpRight, CalendarClock, Flame, Newspaper, Sparkles, TrendingDown, TrendingUp } from "lucide-react";

import { getDashboard, type CalEvent, type Mover } from "@/lib/dashboard.functions";
import { fetchGlobal, fetchMovers, moverLists } from "@/lib/movers";
import { MacroPanel } from "@/components/MacroPanel";
import { PriceAlerts } from "@/components/PriceAlerts";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SignalDesk — Crypto Markets Dashboard & Macro Calendar" },
      { name: "description", content: "Live crypto dashboard: macro economic calendar, top gainers and losers, fear & greed, market news and AI chart analysis." },
      { property: "og:title", content: "SignalDesk — Crypto Markets Dashboard" },
      { property: "og:description", content: "Macro calendar, top movers, sentiment, news and AI-drawn charts in one terminal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: () => getDashboard(),
  component: Dashboard,
});

const big = (n: number) => (n >= 1e12 ? `$${(n / 1e12).toFixed(2)}T` : n >= 1e9 ? `$${(n / 1e9).toFixed(1)}B` : n >= 1e6 ? `$${(n / 1e6).toFixed(n >= 1e8 ? 0 : 1)}M` : `$${(n / 1e3).toFixed(0)}K`);
const px = (n: number) => (n >= 1000 ? n.toLocaleString("en-US", { maximumFractionDigits: 0 }) : n >= 1 ? n.toFixed(2) : n.toPrecision(3));
const pct = (n: number) => `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;

function Dashboard() {
  const initial = Route.useLoaderData();
  const { data: server = initial } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => getDashboard(),
    initialData: initial,
    staleTime: 60_000,
    refetchInterval: 60_000,
  });
  // Some price providers block our server's region — load prices straight from the visitor's browser instead.
  const needMovers = !server.gainers?.length;
  const needGlobal = !server.global;
  const { data: browserMovers } = useQuery({
    queryKey: ["browser-movers"],
    queryFn: async () => moverLists(await fetchMovers()),
    enabled: needMovers,
    refetchInterval: 60_000,
  });
  const { data: browserGlobal } = useQuery({
    queryKey: ["browser-global"],
    queryFn: fetchGlobal,
    enabled: needGlobal,
    refetchInterval: 3 * 60_000,
  });
  const data = {
    ...server,
    ...(needMovers && browserMovers ? browserMovers : {}),
    global: server.global ?? browserGlobal ?? null,
  };
  const fg = data.fearGreed[0];

  return (
    <div className="min-h-screen">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground"><Activity className="size-5" /></div>
            <div>
              <p className="font-display text-lg font-bold tracking-tight">SignalDesk</p>
              <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Markets Terminal</p>
            </div>
          </div>
          <nav className="flex items-center gap-1 text-sm">
            <Link to="/copilot" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Co-Pilot</Link>
            <span className="rounded-md bg-accent px-3 py-1.5 font-semibold text-accent-foreground">Dashboard</span>
            <Link to="/analyze" search={{ coin: undefined }} className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground"><Sparkles className="size-4 text-primary" />AI Chart Analyst</Link>
            <Link to="/journal" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Journal</Link>
            <Link to="/scanner" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Scanner</Link>
            <Link to="/learn" search={{ lesson: undefined }} className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Learn</Link>
          </nav>
        </div>
        <Tape majors={data.majors} />
      </header>

      <main className="mx-auto max-w-7xl space-y-4 px-4 py-6 sm:px-6">
        {/* Top stats */}
        <section className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border lg:grid-cols-5">
          <Stat label="Total market cap" value={data.global ? big(data.global.marketCap) : "–"} sub={data.global ? pct(data.global.change24h) : ""} up={(data.global?.change24h ?? 0) >= 0} />
          <Stat label="24h volume" value={data.global ? big(data.global.volume) : "–"} />
          <Stat label="BTC dominance" value={data.global ? `${data.global.btcDom.toFixed(1)}%` : "–"} />
          <Stat label="ETH dominance" value={data.global ? `${data.global.ethDom.toFixed(1)}%` : "–"} />
          <div className="col-span-2 bg-card px-4 py-3 lg:col-span-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Fear & Greed</p>
            {fg ? <FearGreed value={fg.value} label={fg.label} history={data.fearGreed.map((d) => d.value)} /> : <p>–</p>}
          </div>
        </section>

        <MacroPanel stats={data.macro ?? []} />

        <PriceAlerts majors={data.majors ?? []} />

        {/* News */}
        <section className="rounded-xl border border-border bg-card">
          <h2 className="flex items-center gap-2 border-b border-border px-4 py-3 text-sm font-semibold"><Newspaper className="size-4 text-primary" />Market news</h2>
          <ul className="grid gap-px overflow-hidden rounded-b-xl bg-border md:grid-cols-2">
            {data.news.map((n) => (
              <li key={n.link} className="bg-card">
                <a href={n.link} target="_blank" rel="noreferrer" className="block h-full px-4 py-2.5 hover:bg-accent">
                  <p className="text-sm leading-snug">{n.title}</p>
                  <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">{n.source} · <TimeAgo iso={n.date} /></p>
                </a>
              </li>
            ))}
              {!data.news.length && <li className="px-4 py-6 text-sm text-muted-foreground">News feed unavailable right now.</li>}
            </ul>
          </section>


        <Calendar events={data.calendar} />

        {/* Movers */}
        <div className="grid gap-4 md:grid-cols-3">
          <MoverTable title="Top gainers 24h" icon={<TrendingUp className="size-4 text-bull" />} rows={data.gainers} />
          <MoverTable title="Top losers 24h" icon={<TrendingDown className="size-4 text-bear" />} rows={data.losers} />
          <MoverTable title="Volume leaders" icon={<Flame className="size-4 text-liq" />} rows={data.volumeLeaders} showVol />
        </div>

        <p className="text-center text-[11px] text-muted-foreground">Data: Binance, CoinGecko, Alternative.me, ForexFactory, FRED, Cointelegraph, Decrypt. Refreshes every minute. Not financial advice.</p>
      </main>
    </div>
  );
}

function Tape({ majors }: { majors: Mover[] }) {
  const items = [...majors, ...majors];
  return (
    <div className="overflow-hidden border-t border-border bg-card">
      <div className="flex w-max animate-marquee gap-8 px-4 py-2 text-xs">
        {items.map((m, i) => (
          <Link key={i} to="/analyze" search={{ coin: m.symbol }} className="flex items-center gap-2 whitespace-nowrap hover:text-primary">
            <span className="font-semibold">{m.symbol}</span>
            <span className="font-mono">${px(m.price)}</span>
            <span className={m.change >= 0 ? "text-bull" : "text-bear"}>{pct(m.change)}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

function Stat({ label, value, sub, up }: { label: string; value: string; sub?: string; up?: boolean }) {
  return (
    <div className="bg-card px-4 py-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-display text-xl font-bold">{value}</p>
      {sub && <p className={`text-xs ${up ? "text-bull" : "text-bear"}`}>{sub} 24h</p>}
    </div>
  );
}

function FearGreed({ value, label, history }: { value: number; label: string; history: number[] }) {
  const toneCls = value >= 55 ? "text-bull" : value <= 45 ? "text-bear" : "text-liq";
  return (
    <div className="mt-1">
      <div className="flex items-baseline gap-2"><span className={`font-display text-xl font-bold ${toneCls}`}>{value}</span><span className="text-xs">{label}</span></div>
      <div className="relative mt-1.5 h-1.5 rounded-full bg-gradient-to-r from-bear via-liq to-bull">
        <span className="absolute -top-1 size-3.5 -translate-x-1/2 rounded-full border-2 border-background bg-foreground" style={{ left: `${value}%` }} />
      </div>
      <p className="mt-1.5 text-[10px] text-muted-foreground">7d: {history.slice(1).reverse().join(" · ")}</p>
    </div>
  );
}

function MoverTable({ title, icon, rows, showVol }: { title: string; icon: React.ReactNode; rows: Mover[]; showVol?: boolean }) {
  return (
    <section className="rounded-xl border border-border bg-card">
      <h2 className="flex items-center gap-2 border-b border-border px-4 py-3 text-sm font-semibold">{icon}{title}</h2>
      <table className="w-full text-sm">
        <tbody>
          {rows.map((m) => (
            <tr key={m.symbol} className="border-b border-border/50 last:border-0 hover:bg-accent">
              <td className="px-4 py-2"><Link to="/analyze" search={{ coin: m.symbol }} className="font-semibold hover:text-primary">{m.symbol}</Link></td>
              <td className="px-2 py-2 text-right font-mono text-xs">${px(m.price)}</td>
              <td className="px-4 py-2 text-right">
                {showVol ? <span className="font-mono text-xs text-muted-foreground">{big(m.volume)}</span> : null}
                <span className={`ml-2 inline-flex items-center gap-0.5 font-mono text-xs ${m.change >= 0 ? "text-bull" : "text-bear"}`}>
                  {m.change >= 0 ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}{pct(m.change)}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

const IMPACT_CLS: Record<string, string> = { High: "bg-bear", Medium: "bg-liq", Low: "bg-muted-foreground/50", Holiday: "bg-border" };

function Calendar({ events }: { events: CalEvent[] }) {
  const [filter, setFilter] = useState<"high" | "medium" | "all">("medium");
  const [ccy, setCcy] = useState("ALL");
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(t);
  }, []);

  const currencies = useMemo(() => ["ALL", ...Array.from(new Set(events.map((e) => e.country)))], [events]);
  const shown = events.filter((e) => {
    if (ccy !== "ALL" && e.country !== ccy) return false;
    if (filter === "high") return e.impact === "High";
    if (filter === "medium") return e.impact === "High" || e.impact === "Medium";
    return true;
  });
  const days = useMemo(() => {
    const m = new Map<string, CalEvent[]>();
    for (const e of shown) {
      const k = utcDay(new Date(e.date));
      m.set(k, [...(m.get(k) ?? []), e]);
    }
    return [...m.entries()];
  }, [shown]);
  const next = now ? events.find((e) => e.impact === "High" && Date.parse(e.date) > now) : undefined;

  return (
    <section className="rounded-xl border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
        <h2 className="flex items-center gap-2 text-sm font-semibold"><CalendarClock className="size-4 text-primary" />Macro economic calendar <span className="text-xs font-normal text-muted-foreground">· this week · UTC</span></h2>
        <div className="flex flex-wrap gap-1.5 text-xs">
          {(["high", "medium", "all"] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)} className={`rounded px-2.5 py-1 capitalize ${filter === f ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`}>{f === "medium" ? "Med+" : f}</button>
          ))}
          <select value={ccy} onChange={(e) => setCcy(e.target.value)} className="rounded border border-border bg-background px-2 py-1">
            {currencies.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>
      {next && now && (
        <div className="flex flex-wrap items-center gap-3 border-b border-border bg-bear/10 px-4 py-2.5 text-sm">
          <span className="rounded bg-bear px-1.5 py-0.5 text-[10px] font-bold uppercase text-destructive-foreground">Next high impact</span>
          <span className="font-semibold">{next.country} · {next.title}</span>
          <span className="ml-auto font-mono text-xs">in {countdown(Date.parse(next.date) - now)}</span>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-[10px] uppercase tracking-wider text-muted-foreground">
            <tr className="border-b border-border">
              <th className="px-4 py-2 text-left font-normal">Time</th><th className="px-2 text-left font-normal">Cur</th><th className="px-2 text-left font-normal">Impact</th>
              <th className="px-2 text-left font-normal">Event</th><th className="px-2 text-right font-normal">Forecast</th><th className="px-4 text-right font-normal">Previous</th>
            </tr>
          </thead>
          <tbody>
            {days.map(([day, evs]) => (
              <Fragment key={day}>
                <tr className="bg-background/60"><td colSpan={6} className="px-4 py-1.5 text-xs font-semibold text-primary">{day}</td></tr>
                {evs.map((e, i) => {
                  const past = now ? Date.parse(e.date) < now : false;
                  return (
                    <tr key={day + i} className={`border-b border-border/50 ${past ? "opacity-50" : ""}`}>
                      <td className="px-4 py-2 font-mono text-xs">{utcTime(new Date(e.date))}</td>
                      <td className="px-2 font-semibold">{e.country}</td>
                      <td className="px-2"><span className={`inline-block h-3 w-5 rounded-sm ${IMPACT_CLS[e.impact] ?? "bg-border"}`} title={e.impact} /></td>
                      <td className="px-2">{e.title}</td>
                      <td className="px-2 text-right font-mono text-xs">{e.forecast || "–"}</td>
                      <td className="px-4 text-right font-mono text-xs text-muted-foreground">{e.previous || "–"}</td>
                    </tr>
                  );
                })}
              </Fragment>
            ))}
            {!days.length && <tr><td colSpan={6} className="px-4 py-6 text-center text-muted-foreground">{events.length ? "No events for this filter." : "Economic calendar is refreshing — check back in a few minutes."}</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// Built from UTC parts so the server and the browser always render the same label.
function utcDay(d: Date) {
  return `${DAY_NAMES[d.getUTCDay()]} ${String(d.getUTCDate()).padStart(2, "0")} ${MONTH_NAMES[d.getUTCMonth()]}`;
}
function utcTime(d: Date) {
  return `${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}`;
}

function countdown(ms: number) {
  const m = Math.floor(ms / 60000);
  const d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), mm = m % 60;
  return d ? `${d}d ${h}h` : h ? `${h}h ${mm}m` : `${mm}m`;
}

function TimeAgo({ iso }: { iso: string }) {
  const [txt, setTxt] = useState("");
  useEffect(() => {
    const m = Math.max(0, Math.floor((Date.now() - Date.parse(iso)) / 60000));
    setTxt(m < 60 ? `${m}m ago` : m < 1440 ? `${Math.floor(m / 60)}h ago` : `${Math.floor(m / 1440)}d ago`);
  }, [iso]);
  return <>{txt}</>;
}
