import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Activity, ArrowDownRight, ArrowUpRight, Radar, RefreshCw, Sparkles } from "lucide-react";

import { getScanner, type ScanCategory } from "@/lib/scanner.server";

export const Route = createFileRoute("/scanner")({
  head: () => ({
    meta: [
      { title: "SignalDesk — Market Scanner" },
      { name: "description", content: "Live crypto scanner: breakouts, pullbacks, trend strength, oversold coins, volume surges, funding extremes, new listings and relative strength." },
      { property: "og:title", content: "SignalDesk — Market Scanner" },
      { property: "og:description", content: "Ten live watchlists scanning the crypto market every few minutes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: () => getScanner(),
  errorComponent: ({ error }) => (
    <div role="alert" className="flex min-h-screen items-center justify-center px-4">
      <p className="text-sm text-muted-foreground">The scanner couldn't load: {error instanceof Error ? error.message : String(error)}</p>
    </div>
  ),
  component: ScannerPage,
});

const px = (n: number) => (n >= 1000 ? n.toLocaleString("en-US", { maximumFractionDigits: 0 }) : n >= 1 ? n.toFixed(2) : n.toPrecision(3));

function ScannerPage() {
  const initial = Route.useLoaderData();
  const { data, isFetching } = useQuery({
    queryKey: ["scanner"],
    queryFn: () => getScanner(),
    initialData: initial,
    staleTime: 3 * 60_000,
    refetchInterval: 3 * 60_000,
  });

  return (
    <div className="min-h-screen">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground"><Activity className="size-5" /></div>
            <div>
              <p className="font-display text-lg font-bold tracking-tight">SignalDesk</p>
              <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Markets Terminal</p>
            </div>
          </div>
          <nav className="flex items-center gap-1 text-sm">
            <Link to="/copilot" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Co-Pilot</Link>
            <Link to="/" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Dashboard</Link>
            <Link to="/analyze" search={{ coin: undefined }} className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground"><Sparkles className="size-4 text-primary" />AI Chart Analyst</Link>
            <Link to="/journal" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Journal</Link>
            <span className="flex items-center gap-1.5 rounded-md bg-accent px-3 py-1.5 font-semibold text-accent-foreground"><Radar className="size-4" />Scanner</span>
            <Link to="/learn" search={{ lesson: undefined }} className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Learn</Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">Market Scanner</h1>
            <p className="mt-2 max-w-2xl text-muted-foreground">
              Ten live watchlists, refreshed every few minutes from real market data. Click any coin to open its AI chart analysis. Not financial advice.
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1.5 text-xs text-muted-foreground">
            <RefreshCw className={`size-3.5 ${isFetching ? "animate-spin" : ""}`} />
            {data.scannedAt ? `Updated ${new Date(data.scannedAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "UTC" })} UTC` : ""}
          </div>
        </div>

        {!data.categories.length && (
          <div className="mt-8 rounded-xl border border-border bg-card p-8 text-center text-muted-foreground shadow-sm">
            The scanner is warming up — check back in a minute.
          </div>
        )}

        <div className="mt-8 grid gap-5 md:grid-cols-2">
          {data.categories.map((c) => (
            <CategoryCard key={c.id} category={c} />
          ))}
        </div>
      </main>
    </div>
  );
}

function CategoryCard({ category }: { category: ScanCategory }) {
  return (
    <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <h2 className="font-display text-lg font-bold tracking-tight">{category.title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{category.blurb}</p>
      {category.hits.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">No coins match right now.</p>
      ) : (
        <ul className="mt-3 divide-y divide-border">
          {category.hits.map((h) => (
            <li key={h.symbol}>
              <Link to="/analyze" search={{ coin: h.symbol }} className="group flex items-center gap-3 py-2.5">
                <span className="w-16 font-semibold group-hover:text-primary">{h.symbol}</span>
                <span className="w-20 text-sm text-muted-foreground">${px(h.price)}</span>
                <span className={`flex w-16 items-center gap-0.5 text-sm font-medium ${h.change >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {h.change >= 0 ? <ArrowUpRight className="size-3.5" /> : <ArrowDownRight className="size-3.5" />}
                  {Math.abs(h.change).toFixed(1)}%
                </span>
                <span className="flex-1 text-right text-xs text-muted-foreground">{h.detail}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
