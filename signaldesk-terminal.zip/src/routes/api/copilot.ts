import { createFileRoute } from "@tanstack/react-router";
import { handleCopilot } from "@/lib/ai/copilot.server";

export const Route = createFileRoute("/api/copilot")({
  server: { handlers: { POST: ({ request }) => handleCopilot(request) } },
});
