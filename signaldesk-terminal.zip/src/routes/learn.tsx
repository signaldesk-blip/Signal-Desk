import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Activity, ArrowLeft, ArrowRight, BookOpen, Check, CheckCircle2, GraduationCap, Sparkles } from "lucide-react";

import { LEVELS, ALL_LESSONS, type Lesson } from "@/lib/learn";
import { LEVEL_IMAGES, LessonVisual } from "@/components/LessonVisual";
import { LESSON_IMAGES } from "@/lib/lesson-images";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "SignalDesk — Learn Crypto Trading" },
      { name: "description", content: "A structured, plain-English learning path: crypto basics, reading markets, trading skills and advanced analysis." },
      { property: "og:title", content: "SignalDesk — Learn Crypto Trading" },
      { property: "og:description", content: "Four levels of plain-English lessons, from 'What is Bitcoin?' to advanced market analysis." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>) => ({ lesson: typeof s["lesson"] === "string" ? (s["lesson"] as string) : undefined }),
  component: LearnPage,
});

const STORAGE_KEY = "signaldesk-learn-progress";

function useProgress() {
  const [done, setDone] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
    } catch {
      return [];
    }
  });
  const toggle = (id: string) =>
    setDone((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  return { done, toggle };
}

function LearnPage() {
  const { lesson: lessonId } = Route.useSearch();
  const { done, toggle } = useProgress();
  const lesson = ALL_LESSONS.find((l) => l.id === lessonId);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [lessonId]);

  return (
    <div className="min-h-screen">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground"><Activity className="size-5" /></div>
            <div>
              <p className="font-display text-lg font-bold tracking-tight">SignalDesk</p>
              <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Markets Terminal</p>
            </div>
          </div>
          <nav className="flex items-center gap-1 text-sm">
            <Link to="/copilot" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Co-Pilot</Link>
            <Link to="/" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Dashboard</Link>
            <Link to="/analyze" search={{ coin: undefined }} className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground"><Sparkles className="size-4 text-primary" />AI Chart Analyst</Link>
            <Link to="/journal" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Journal</Link>
            <Link to="/scanner" className="rounded-md px-3 py-1.5 text-muted-foreground hover:text-foreground">Scanner</Link>
            <span className="flex items-center gap-1.5 rounded-md bg-accent px-3 py-1.5 font-semibold text-accent-foreground"><GraduationCap className="size-4" />Learn</span>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        {lesson ? (
          <LessonView lesson={lesson} done={done.includes(lesson.id)} onToggle={() => toggle(lesson.id)} />
        ) : (
          <PathView done={done} />
        )}
      </main>
    </div>
  );
}

function PathView({ done }: { done: string[] }) {
  const total = ALL_LESSONS.length;
  const pctDone = Math.round((done.length / total) * 100);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Learn crypto, step by step</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          A structured path from the very basics to advanced market analysis — written in plain English, no jargon left unexplained. Your progress is saved in this browser.
        </p>
        <div className="mt-4 flex items-center gap-3">
          <div className="h-2 w-64 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pctDone}%` }} />
          </div>
          <span className="text-sm text-muted-foreground">{done.length} of {total} lessons · {pctDone}%</span>
        </div>
      </div>

      {LEVELS.map((level, li) => {
        const levelDone = level.lessons.filter((l) => done.includes(l.id)).length;
        return (
          <section key={level.id} className="border-t border-border bg-card py-6">
            {LEVEL_IMAGES[level.id] && <img src={LEVEL_IMAGES[level.id]?.src} alt={LEVEL_IMAGES[level.id]?.alt} width={1536} height={1024} loading="lazy" className="mb-5 h-44 w-full object-contain sm:h-56" />}
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-display text-xl font-bold tracking-tight">{level.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{level.tagline}</p>
              </div>
              <span className="shrink-0 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
                {levelDone}/{level.lessons.length} done
              </span>
            </div>
            <ol className="mt-4 divide-y divide-border">
              {level.lessons.map((lesson, i) => {
                const isDone = done.includes(lesson.id);
                return (
                  <li key={lesson.id}>
                    <Link
                      to="/learn"
                      search={{ lesson: lesson.id }}
                      className="group flex items-center gap-3 py-3"
                    >
                      <span className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${isDone ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                        {isDone ? <Check className="size-4" /> : i + 1}
                      </span>
                      {LESSON_IMAGES[lesson.id] && <img src={LESSON_IMAGES[lesson.id]} alt="" width={72} height={72} loading="lazy" className="size-16 shrink-0 rounded-md bg-card object-contain sm:size-20" />}
                      <span className={`flex-1 font-medium group-hover:text-primary ${isDone ? "text-muted-foreground line-through" : ""}`}>
                        {lesson.title}
                      </span>
                      <span className="text-xs text-muted-foreground">{lesson.minutes} min</span>
                      <ArrowRight className="size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                    </Link>
                  </li>
                );
              })}
            </ol>
          </section>
        );
      })}
    </div>
  );
}

function LessonView({ lesson, done, onToggle }: { lesson: Lesson; done: boolean; onToggle: () => void }) {
  const idx = ALL_LESSONS.findIndex((l) => l.id === lesson.id);
  const prev = ALL_LESSONS[idx - 1];
  const next = ALL_LESSONS[idx + 1];
  const level = LEVELS.find((l) => l.lessons.some((x) => x.id === lesson.id));

  return (
    <article className="mx-auto max-w-3xl">
      <Link to="/learn" search={{ lesson: undefined }} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Back to learning path
      </Link>

      <p className="mt-6 text-xs font-semibold uppercase tracking-[0.15em] text-primary">{level?.title}</p>
      <h1 className="mt-2 font-display text-3xl font-bold tracking-tight">{lesson.title}</h1>
      <p className="mt-1 text-sm text-muted-foreground">{lesson.minutes} minute read</p>

      <LessonVisual lessonId={lesson.id} />

      <div className="mt-6 space-y-4">
        {lesson.body.map((p, i) => (
          <p key={i} className="leading-relaxed text-foreground/90">{p}</p>
        ))}
      </div>

      <div className="mt-6 rounded-xl border border-border bg-accent/40 p-6">
        <h2 className="flex items-center gap-2 font-display text-lg font-bold"><BookOpen className="size-5 text-primary" /> Key points to remember</h2>
        <ul className="mt-3 space-y-2">
          {lesson.keyPoints.map((k, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>{k}</span>
            </li>
          ))}
        </ul>
      </div>

      <button
        onClick={onToggle}
        className={`mt-6 inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors ${done ? "bg-muted text-muted-foreground hover:bg-muted/70" : "bg-primary text-primary-foreground hover:bg-primary/90"}`}
      >
        <Check className="size-4" /> {done ? "Completed — tap to undo" : "Mark as complete"}
      </button>

      <div className="mt-8 flex items-center justify-between border-t border-border pt-6 text-sm">
        {prev ? (
          <Link to="/learn" search={{ lesson: prev.id }} className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="size-4" /> {prev.title}
          </Link>
        ) : <span />}
        {next ? (
          <Link to="/learn" search={{ lesson: next.id }} className="flex items-center gap-1.5 font-medium text-primary hover:underline">
            Next: {next.title} <ArrowRight className="size-4" />
          </Link>
        ) : (
          <Link to="/learn" search={{ lesson: undefined }} className="font-medium text-primary hover:underline">Back to the full path</Link>
        )}
      </div>
    </article>
  );
}
