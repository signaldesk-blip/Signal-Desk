import { useViewMode } from "@/lib/view-mode";
import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Activity, ArrowDownRight, ArrowUpRight, Bitcoin, CircleDollarSign, Coins, Currency, Gem,
  Loader2, Minus, ShieldAlert, Square, TrendingUp, Zap,
} from "lucide-react";

import { MarketChart, type Candle, type Layers, type Level, type Liq, type OIPoint, type Zone } from "@/components/MarketChart";
import { ChartSurfaceToggle } from "@/components/ChartSurfaceToggle";
import { useChartSurface } from "@/lib/chart-surface";

export const Route = createFileRoute("/analyze")({
  head: () => ({
    meta: [
      { title: "SignalDesk — AI Crypto Chart Analyst" },
      { name: "description", content: "Pick a coin and get live interactive charts with AI-drawn supply & demand zones, key levels and real liquidation clusters." },
      { property: "og:title", content: "SignalDesk — AI Crypto Chart Analyst" },
      { property: "og:description", content: "Live interactive charts with AI-drawn supply & demand zones, key levels and liquidation clusters." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>) => ({ coin: typeof s['coin'] === "string" ? s['coin'] : undefined }),
  component: Index,
});

const COINS = [
  { symbol: "BTC", name: "Bitcoin", icon: Bitcoin },
  { symbol: "ETH", name: "Ethereum", icon: Gem },
  { symbol: "SOL", name: "Solana", icon: Zap },
  { symbol: "XRP", name: "XRP", icon: CircleDollarSign },
  { symbol: "DOGE", name: "Dogecoin", icon: Coins },
  { symbol: "ADA", name: "Cardano", icon: Currency },
  { symbol: "LINK", name: "Chainlink", icon: Activity },
  { symbol: "AVAX", name: "Avalanche", icon: TrendingUp },
];

type Sentiment = "bullish" | "bearish" | "neutral";
type Analysis = {
  bias: Sentiment; confidence: number; headline: string;
  zones: Zone[]; levels: Level[];
  signals: { name: string; reading: string; sentiment: Sentiment }[];
  bull: { trigger: number; target: number; points: string[] };
  bear: { trigger: number; target: number; points: string[] };
  why: string[];
};
type Market = {
  ticker: string;
  candles: Record<"1w" | "1d" | "4h", Candle[]>;
  stats: { price: number; change24h: number; rsiD: number | null; rsi4h: number | null; fundingRate: number | null; btcCorrelation30d: number | null };
};
type TF = "1w" | "1d" | "4h";
type OIData = { "1h": OIPoint[]; "1d": OIPoint[]; latestUsd: number; change24hPct: number | null; change7dPct: number | null };
const bigUsd = (n: number) => (n >= 1e9 ? `$${(n / 1e9).toFixed(2)}B` : `$${(n / 1e6).toFixed(0)}M`);

const fmt = (n: number) => n >= 1000 ? n.toLocaleString("en-US", { maximumFractionDigits: 0 }) : n >= 1 ? n.toFixed(2) : n.toPrecision(4);
const tone = (s: Sentiment) => (s === "bullish" ? "text-bull" : s === "bearish" ? "text-bear" : "text-muted-foreground");
const SentIcon = ({ s }: { s: Sentiment }) => s === "bullish" ? <ArrowUpRight className="size-4 text-bull" /> : s === "bearish" ? <ArrowDownRight className="size-4 text-bear" /> : <Minus className="size-4 text-muted-foreground" />;

function Index() {
  const [selected, setSelected] = useState("BTC");
  const [custom, setCustom] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [data, setData] = useState<{ market: Market; analysis: Analysis; liquidations: Liq[]; openInterest: OIData | null } | null>(null);
  const [tf, setTf] = useState<TF>("4h");
  const [layers, setLayers] = useState<Layers>({ zones: true, levels: true, liquidations: true, oi: true });
  const surface = useChartSurface();
  const mode = useViewMode();
  const adv = mode.advanced;
  const abortRef = useRef<AbortController | null>(null);
  const { coin: initialCoin } = Route.useSearch();

  const analyze = async (coin: string) => {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true); setError(""); setData(null);
    try {
      const res = await fetch("/api/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ coin }), signal: ctrl.signal });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Analysis failed.");
      setData(json);
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return;
      setError(e instanceof Error ? e.message : "Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialCoin) {
      const c = initialCoin.toUpperCase();
      if (COINS.some((x) => x.symbol === c)) setSelected(c); else setCustom(c);
      void analyze(c);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialCoin]);

  const a = data?.analysis;
  const candles = useMemo(() => data?.market.candles[tf] ?? [], [data, tf]);
  const layerKey = useMemo(() => (adv ? { ...layers } : { zones: true, levels: true, liquidations: false, oi: false }), [layers, adv]);

  return (
    <div className="mx-auto min-h-screen max-w-6xl px-4 pb-24 sm:px-6">
      <header className="flex items-center justify-between border-b border-border py-5">
        <div className="flex items-center gap-3">
          <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground"><Activity className="size-5" /></div>
          <div>
            <p className="font-display text-lg font-bold tracking-tight">SignalDesk</p>
            <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">AI Chart Analyst</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div role="group" aria-label="View mode" className="flex rounded-lg border border-border bg-background p-0.5 text-sm">
            {([[false, "Simple"], [true, "Advanced"]] as const).map(([v, label]) => (
              <button key={label} aria-pressed={adv === v} onClick={() => mode.choose(v)}
                className={`rounded-md px-3 py-1.5 font-semibold ${adv === v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{label}</button>
            ))}
          </div>
          <span className="flex flex-wrap gap-3"><Link to="/" className="text-xs text-muted-foreground hover:text-primary">← Markets dashboard</Link><Link to="/journal" className="text-xs text-muted-foreground hover:text-primary">Journal</Link><Link to="/scanner" className="text-xs text-muted-foreground hover:text-primary">Scanner</Link><Link to="/learn" search={{ lesson: undefined }} className="text-xs text-muted-foreground hover:text-primary">Learn</Link><Link to="/copilot" className="text-xs text-muted-foreground hover:text-primary">Co-Pilot</Link></span>
        </div>
      </header>

      {/* Selector */}
      <section className="mt-6 flex flex-col gap-3 rounded-xl border border-border bg-card p-4 card-glow lg:flex-row lg:items-center">
        <div className="flex flex-wrap gap-1.5">
          {COINS.map(({ symbol, icon: Icon }) => {
            const active = selected === symbol && !custom;
            return (
              <button key={symbol} onClick={() => { setSelected(symbol); setCustom(""); }}
                className={`flex items-center gap-1.5 rounded-md border px-3 py-2 text-sm font-semibold transition-colors ${active ? "border-primary bg-accent text-accent-foreground" : "border-border bg-background hover:border-primary/50"}`}>
                <Icon className={`size-4 ${active ? "text-primary" : "text-muted-foreground"}`} />{symbol}
              </button>
            );
          })}
        </div>
        <div className="flex flex-1 gap-2">
          <input value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="Other ticker — DOT, NEAR, PEPE…"
            className="h-10 min-w-0 flex-1 rounded-md border border-input bg-background px-3 text-sm outline-none placeholder:text-muted-foreground focus:border-primary" />
          {loading ? (
            <button onClick={() => { abortRef.current?.abort(); setLoading(false); }} className="inline-flex h-10 items-center gap-2 rounded-md border border-destructive px-4 text-sm font-semibold text-destructive"><Square className="size-4" />Stop</button>
          ) : (
            <button onClick={() => analyze(custom.trim() || selected)} className="inline-flex h-10 items-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground hover:opacity-90"><TrendingUp className="size-4" />Analyze</button>
          )}
        </div>
      </section>

      {!data && !loading && !error && (
        <section className="py-20 text-center">
          <h1 className="font-display text-4xl font-bold tracking-tight text-glow sm:text-5xl">See the market, not paragraphs.</h1>
          <p className="mx-auto mt-4 max-w-lg text-sm text-muted-foreground">Pick a coin. The AI reads weekly, daily and 4H charts plus volume, RSI, funding and open interest — then draws supply & demand zones and key levels right on the chart.</p>
        </section>
      )}

      {loading && (
        <section className="mt-6 flex h-[500px] flex-col items-center justify-center gap-3 rounded-xl border border-border bg-card text-sm text-muted-foreground">
          <Loader2 className="size-6 animate-spin text-primary" />Reading the charts and marking zones…
        </section>
      )}

      {error && (
        <div className="mt-6 flex items-start gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm"><ShieldAlert className="mt-0.5 size-4 shrink-0 text-destructive" /><p>{error}</p></div>
      )}

      {data && a && (
        <>
          {/* Stat strip */}
          {adv ? (
          <section className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-6">
            <Stat label={`${data.market.ticker}/USDT`} value={`$${fmt(data.market.stats.price)}`} sub={`${data.market.stats.change24h >= 0 ? "+" : ""}${data.market.stats.change24h.toFixed(2)}% 24h`} subTone={data.market.stats.change24h >= 0 ? "text-bull" : "text-bear"} />
            <Stat label="Bias" value={a.bias.toUpperCase()} valueTone={tone(a.bias)} sub={`${Math.round(a.confidence)}% confidence`} />
            <Stat label="RSI D / 4H" value={`${data.market.stats.rsiD?.toFixed(0) ?? "–"} / ${data.market.stats.rsi4h?.toFixed(0) ?? "–"}`} />
            <Stat label="Funding" value={data.market.stats.fundingRate == null ? "n/a" : `${(data.market.stats.fundingRate * 100).toFixed(4)}%`} />
            <Stat label="Open interest" value={data.openInterest ? bigUsd(data.openInterest.latestUsd) : "n/a"} sub={data.openInterest?.change24hPct != null ? `${data.openInterest.change24hPct >= 0 ? "+" : ""}${data.openInterest.change24hPct.toFixed(1)}% 24h` : undefined} subTone={(data.openInterest?.change24hPct ?? 0) >= 0 ? "text-bull" : "text-bear"} />
            <Stat label="BTC corr 30d" value={data.market.stats.btcCorrelation30d?.toFixed(2) ?? "–"} />
          </section>
          ) : (
          <section className="mt-6 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3">
            <div className="bg-card px-5 py-4">
              <p className="text-sm text-muted-foreground">Price of {data.market.ticker} today</p>
              <p className="mt-1 font-display text-3xl font-bold">${fmt(data.market.stats.price)}</p>
              <p className={`mt-1 text-base ${data.market.stats.change24h >= 0 ? "text-bull" : "text-bear"}`}>{data.market.stats.change24h >= 0 ? "Up" : "Down"} {Math.abs(data.market.stats.change24h).toFixed(1)}% since yesterday</p>
            </div>
            <div className="bg-card px-5 py-4">
              <p className="text-sm text-muted-foreground">Our AI's overall view</p>
              <p className={`mt-1 font-display text-3xl font-bold ${tone(a.bias)}`}>{a.bias === "bullish" ? "Leaning up" : a.bias === "bearish" ? "Leaning down" : "Undecided"}</p>
              <p className="mt-1 text-base text-muted-foreground">{a.confidence >= 70 ? "Fairly sure" : a.confidence >= 45 ? "Somewhat sure" : "Not very sure"} ({Math.round(a.confidence)}%)</p>
            </div>
            <div className="bg-card px-5 py-4">
              <p className="text-sm text-muted-foreground">Is it overheated?</p>
              {(() => { const r = data.market.stats.rsiD; const t = r == null ? "Unknown" : r >= 70 ? "Yes — bought a lot recently" : r <= 30 ? "No — sold off a lot recently" : "No — in a normal range"; return <p className="mt-1 font-display text-xl font-bold">{t}</p>; })()}
            </div>
          </section>
          )}

          <p className={`mt-4 font-display font-semibold ${adv ? "text-lg" : "text-xl"}`}>{a.headline}</p>

          {/* Chart */}
          <section className={`mt-3 rounded-xl border border-border bg-card card-glow ${surface.dark ? "chart-dark" : ""}`}>
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-2.5">
              <div className="flex gap-1">
                {(["1w", "1d", "4h"] as TF[]).map((t) => (
                  <button key={t} onClick={() => setTf(t)} className={`rounded px-3 py-1 font-semibold ${adv ? "text-xs uppercase" : "text-sm"} ${tf === t ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{adv ? t : t === "1w" ? "Long term" : t === "1d" ? "Medium term" : "Short term"}</button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                {adv && ([["zones", "S/D zones"], ["levels", "Levels"], ["liquidations", "Liquidations"], ["oi", "Open interest"]] as [keyof Layers, string][]).map(([k, label]) => (
                  <button key={k} onClick={() => setLayers((l) => ({ ...l, [k]: !l[k] }))}
                    className={`rounded border px-2.5 py-1 ${layers[k] ? "border-primary/60 text-foreground" : "border-border text-muted-foreground line-through"}`}>{label}</button>
                ))}
                <ChartSurfaceToggle dark={surface.dark} onChoose={surface.choose} />
              </div>
            </div>
            <div className="p-2">
              <MarketChart candles={candles} zones={a.zones.filter((z) => !z.timeframe || z.timeframe === tf)} levels={a.levels.filter((l) => !(l as { timeframe?: string }).timeframe || (l as { timeframe?: string }).timeframe === tf)} liquidations={data.liquidations} layers={layerKey} openInterest={data.openInterest ? (tf === "4h" ? data.openInterest["1h"] : data.openInterest["1d"]) : undefined} />
            </div>
            {adv ? (
            <div className="flex flex-wrap gap-4 border-t border-border px-4 py-2 text-[11px] text-muted-foreground">
              <Legend cls="bg-bull/40" label="Demand" /><Legend cls="bg-bear/40" label="Supply" /><Legend cls="bg-liq" label="Real liquidations" /><Legend cls="bg-liq" label="Open interest (OKX)" />
              <span className="ml-auto">Panes: price · volume · RSI(14) · OI — scroll to zoom, drag to pan</span>
            </div>
            ) : (
            <div className="grid gap-2 border-t border-border px-4 py-3 text-sm sm:grid-cols-2">
              <Legend cls="bg-bull/40" label="Green areas: prices where buyers have stepped in before (a possible floor)" />
              <Legend cls="bg-bear/40" label="Red areas: prices where sellers have stepped in before (a possible ceiling)" />
            </div>
            )}
          </section>

          {!adv && (
            <section className="mt-4 grid gap-4 md:grid-cols-2">
              <div className="rounded-xl border border-bull/40 bg-card p-5">
                <p className="font-semibold text-bull">If things go well</p>
                <p className="mt-2 text-base">If the price climbs above <b>${fmt(a.bull.trigger)}</b>, it could head towards <b className="text-bull">${fmt(a.bull.target)}</b>.</p>
              </div>
              <div className="rounded-xl border border-bear/40 bg-card p-5">
                <p className="font-semibold text-bear">If things go badly</p>
                <p className="mt-2 text-base">If the price falls below <b>${fmt(a.bear.trigger)}</b>, it could drop towards <b className="text-bear">${fmt(a.bear.target)}</b>.</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-5 md:col-span-2">
                <p className="font-semibold">Why the AI thinks this</p>
                <ul className="mt-2 space-y-1.5 text-base">{a.why.map((w, i) => <li key={i} className="flex gap-2"><span className="text-primary">→</span>{w}</li>)}</ul>
                <p className="mt-4 text-sm text-muted-foreground">This is a computer's reading of the chart, not financial advice. Crypto prices can fall sharply — never invest money you can't afford to lose. Switch to <b>Advanced</b> for indicators and liquidation data.</p>
              </div>
            </section>
          )}

          {adv && <>
          {/* Scenarios */}
          <section className="mt-4 grid gap-4 md:grid-cols-2">
            <Scenario title="Bull case" s={a.bull} toneCls="text-bull" border="border-bull/40" />
            <Scenario title="Bear case" s={a.bear} toneCls="text-bear" border="border-bear/40" />
          </section>

          {/* Signals */}
          <section className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-5">
            {a.signals.map((s) => (
              <div key={s.name} className="rounded-lg border border-border bg-card p-3">
                <div className="flex items-center justify-between"><span className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.name}</span><SentIcon s={s.sentiment} /></div>
                <p className={`mt-1 text-xs font-medium ${tone(s.sentiment)}`}>{s.reading}</p>
              </div>
            ))}
          </section>

          {/* Why */}
          <section className="mt-4 rounded-xl border border-border bg-card p-4">
            <p className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Why this conclusion</p>
            <ul className="mt-2 space-y-1 text-sm">{a.why.map((w, i) => <li key={i} className="flex gap-2"><span className="text-primary">→</span>{w}</li>)}</ul>
            <p className="mt-3 text-[11px] text-muted-foreground">Live prices from Binance, funding from OKX. Liquidations are real recent fills from OKX perpetuals. Not financial advice.</p>
          </section>
          </>}
        </>
      )}
    </div>
  );
}

function Stat({ label, value, sub, valueTone = "", subTone = "text-muted-foreground" }: { label: string; value: string; sub?: string | undefined; valueTone?: string; subTone?: string }) {
  return (
    <div className="bg-card px-4 py-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className={`mt-0.5 font-display text-lg font-bold ${valueTone}`}>{value}</p>
      {sub && <p className={`text-[11px] ${subTone}`}>{sub}</p>}
    </div>
  );
}

function Legend({ cls, label }: { cls: string; label: string }) {
  return <span className="flex items-center gap-1.5"><span className={`size-2.5 rounded-sm ${cls}`} />{label}</span>;
}

function Scenario({ title, s, toneCls, border }: { title: string; s: Analysis["bull"]; toneCls: string; border: string }) {
  return (
    <div className={`rounded-xl border ${border} bg-card p-4`}>
      <p className={`text-[11px] font-semibold uppercase tracking-[0.2em] ${toneCls}`}>{title}</p>
      <div className="mt-2 flex gap-4 font-mono text-xs">
        <span><span className="text-muted-foreground">Trigger </span>{fmt(s.trigger)}</span>
        <span><span className="text-muted-foreground">Target </span><span className={toneCls}>{fmt(s.target)}</span></span>
      </div>
      <ul className="mt-2 space-y-1 text-sm">{s.points.map((p, i) => <li key={i} className="flex gap-2"><span className={toneCls}>•</span>{p}</li>)}</ul>
    </div>
  );
}
